//
//  helloWorld_001ViewController.h
//  helloWorld_001
//
//  Created by Rory Lewis on 6/13/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface helloWorld_001ViewController : UIViewController {
	IBOutlet UILabel *label;
}

- (IBAction)hello:(id)sendr;

@end

