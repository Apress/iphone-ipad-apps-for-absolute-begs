//
//  helloWorld_001AppDelegate.m
//  helloWorld_001
//
//  Created by Rory Lewis on 6/13/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "helloWorld_001AppDelegate.h"
#import "helloWorld_001ViewController.h"

@implementation helloWorld_001AppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
