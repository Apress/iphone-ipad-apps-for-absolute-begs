//
//  helloWorld_001AppDelegate.h
//  helloWorld_001
//
//  Created by Rory Lewis on 6/13/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class helloWorld_001ViewController;

@interface helloWorld_001AppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    helloWorld_001ViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet helloWorld_001ViewController *viewController;

@end

