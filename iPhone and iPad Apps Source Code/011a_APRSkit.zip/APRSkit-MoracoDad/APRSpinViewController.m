//
//  APRSpinViewController.m
//  APRSkit-MoracoDad
//
//  Created by Stephen on 10/24/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import "APRSpinViewController.h"
#import "PinAnnotation.h"
#import "PinAnnotationView.h"
#import "APRSkit_MoracoDadAppDelegate.h"

@implementation APRSpinViewController

@synthesize mapView = m_mvMap;
@synthesize ctlMapTypeChooser = m_ctlMapTypeChooser;
@synthesize locationManager = m_lmLocationManager;
@synthesize reverseGeocoder = m_rgReverseGeocoder;
@synthesize webBrowserController = m_wvBrowserController;


/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	NSLog(@"APRSpinViewController:viewDidLoad - ENTRY");
	self.ctlMapTypeChooser.selectedSegmentIndex = 1;	// preset to satellite form
	[self.ctlMapTypeChooser addTarget:self action:@selector(selectMapMode:) forControlEvents:UIControlEventValueChanged];
	
	self.mapView.showsUserLocation = YES;

	self.locationManager = [[CLLocationManager alloc] init];
	self.locationManager.delegate = self;
	[self.locationManager startUpdatingLocation];	
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}

- (void)dealloc {
	[self.webBrowserController release], self.webBrowserController = nil;
	[self.mapView release], self.mapView = nil;
	[self.ctlMapTypeChooser release], self.ctlMapTypeChooser = nil;
	[self.locationManager release], self.locationManager = nil;
	[self.reverseGeocoder release], self.reverseGeocoder = nil;
    [super dealloc];
}

#pragma mark -
#pragma mark CLLocationManagerDelegate methods

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation {
	
	// Add annotation to map
	PinAnnotation *annotation = [[PinAnnotation alloc] initWithCoordinate:newLocation.coordinate title:@"Drag to move Pin"];
	[self.mapView addAnnotation:annotation];
	[annotation release];
	
	// We only update location once, and let users to do the rest of the changes by dragging annotation to place they want
	[manager stopUpdatingLocation];
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
}

#pragma mark -
#pragma mark UI Action Methods

-(IBAction)sendPostion:(id)sender
{
	NSLog(@"APRSpinViewController:sendPostion - ENTRY");
}

-(IBAction)selectMapMode:(id)sender
{
	UISegmentedControl *scChooser = (UISegmentedControl *)sender;
	int nMapStyleIdx = [scChooser selectedSegmentIndex];
	NSLog(@"APRSpinViewController:selectMapMode - New Style=%d",nMapStyleIdx);
	
	switch (nMapStyleIdx) {
		case 0:
			self.mapView.mapType = MKMapTypeStandard;
			break;
		case 1:
			self.mapView.mapType = MKMapTypeSatellite;
			break;
		case 2:
			self.mapView.mapType = MKMapTypeHybrid;
			break;
		default:
			NSLog(@"APRSpinViewController:selectMapMode - Unknown Selection?!");
			break;
	}
}


#pragma mark -
#pragma mark Utilty Methods

- (void)recenterMap {
	NSLog(@" - APRSpinViewController:recenterMap - ENTRY");
	// scan all annotations to determin geographical center...
	NSArray *coordinates = [self.mapView valueForKeyPath:@"annotations.coordinate"];
	CLLocationCoordinate2D maxCoord = {-90.0f, -180.0f};
	CLLocationCoordinate2D minCoord = {90.0f, 180.0f};
	for(NSValue *value in coordinates) {
		CLLocationCoordinate2D coord = {0.0f, 0.0f};
		[value getValue:&coord];
			if(coord.longitude > maxCoord.longitude) {
				maxCoord.longitude = coord.longitude;
			}
			if(coord.latitude > maxCoord.latitude) {
				maxCoord.latitude = coord.latitude;
			}
			if(coord.longitude < minCoord.longitude) {
				minCoord.longitude = coord.longitude;
			}
			if(coord.latitude < minCoord.latitude) {
				minCoord.latitude = coord.latitude;
			}
	}
	// now calculate region of map to display
	MKCoordinateRegion region = {{0.0f, 0.0f}, {0.0f, 0.0f}};
	region.center.longitude = (minCoord.longitude + maxCoord.longitude) / 2.0;
	region.center.latitude = (minCoord.latitude + maxCoord.latitude) / 2.0;
	
	region.span.longitudeDelta = maxCoord.longitude - minCoord.longitude;
	region.span.latitudeDelta = maxCoord.latitude - minCoord.latitude;
	
	if (region.span.longitudeDelta == 0) {
		// hmmm no span so let's approximate 1/2 mile
		//   lat = 1/(69*2) or 1/138 or 0.00725f
		//   long = move up from equator for mid USA, 1/(49*2) or 1/98 or 0.01020f
		region.span.longitudeDelta = 0.0102f;
		region.span.latitudeDelta = 0.00725f;
	}
	[self.mapView setRegion:region animated:YES];  
	NSLog(@" - APRSpinViewController:recenterMap - EXIT");
}


#pragma mark -
#pragma mark MKMapViewDelegate Methods

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation {
	
	if (annotation == mapView.userLocation) {
		return nil;
	}
	
	PinAnnotationView *annotationView = (PinAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:@"Pin"];
	if (annotationView == nil) {
		annotationView = [[[PinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"Pin"] autorelease];
	}
	// Dragging annotation will need _mapView to convert new point to coordinate;
	annotationView.mapView = mapView;
	
	return annotationView;
}

-(void)mapView:(MKMapView *)mapView didAddAnnotationViews:(NSArray *)viewsAr
{
	NSLog(@"mapView:didAddAnnotationViews - ENTRY");
	[self recenterMap];
}

-(void)mapViewDidFinishLoadingMap:(MKMapView *)mapView
{
	NSLog(@"mapViewDidFinishLoadingMap - ENTRY");
}

-(void)mapViewWillStartLoadingMap:(MKMapView *)mapView
{
	NSLog(@"mapViewWillStartLoadingMap - ENTRY");
}

- (void)mapView:(MKMapView *)mapView 
 annotationView:(MKAnnotationView *)view 
calloutAccessoryControlTapped:(UIControl *)control {

	// preserve for action sheet handler to use
	m_paNewLocation = (PinAnnotation *)[view annotation];

	// open a dialog with an OK and cancel button
		UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"Ready to report this Postiion?"
																 delegate:self 
														cancelButtonTitle:@"Cancel" 
												   destructiveButtonTitle:@"Report Position" 
														otherButtonTitles:nil];
		actionSheet.actionSheetStyle = UIActionSheetStyleBlackTranslucent;
		[actionSheet showInView:self.view]; // show from our table view (pops up in the middle of the table)
		[actionSheet release];
}


#pragma mark -
#pragma mark UIActionSheetDelegate methods

static NSString *s_strFeedURLBaseString = @"http://www.findU.com/cgi-bin/inputpos.cgi?call=%@&passwd=%@&lat=%f&lon=%f";

-(void)registerNewLocation:(PinAnnotation *)newLocation
{
	NSLog(@"registerNewLocation - ENTRY");
	double fLatitude = newLocation.coordinate.latitude;
	double fLongitude = newLocation.coordinate.longitude;
	
	APRSkit_MoracoDadAppDelegate *appDelegate = (APRSkit_MoracoDadAppDelegate *)[[UIApplication sharedApplication] delegate];
	NSString *strCurrCallsign = appDelegate.callSign;
	NSString *strCurrPassword = appDelegate.sitePassword;
	
	NSString *strBuiltURL = [NSString stringWithFormat:s_strFeedURLBaseString,strCurrCallsign,strCurrPassword,fLatitude,fLongitude];
	NSLog(@"URL=[%@]",strBuiltURL);
	
	// build URL
	NSURL *url = [NSURL URLWithString:strBuiltURL];
	// set URL
	if(self.webBrowserController == nil)
	{
		self.webBrowserController = [[APRSwebViewController alloc] initWithNibName:@"APRSwebView" bundle:nil];
	}
	self.webBrowserController.pageURL = url;
	// switch to the selected view
	[self.navigationController pushViewController:self.webBrowserController animated:YES];
	NSLog(@"registerNewLocation - EXIT");
}

-(void)actionSheet:(UIActionSheet *)sendingSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
	NSLog(@"actionSheet:clickedButtonAtIndex:%d",buttonIndex);

	if(buttonIndex != -1)
	{
		switch (buttonIndex) {
			case 0:
			{
				// Sending button was clicked, let's ask for location to be registered
				[self registerNewLocation:m_paNewLocation];
			}
			break;
			default:
				NSLog(@"actionSheet:clickedButtonAtIndex Unknown Case");
				break;
		}
	}
	else
	{
		NSLog(@"actionSheet:clickedButtonAtIndex Canceled");
	}
}


@end
