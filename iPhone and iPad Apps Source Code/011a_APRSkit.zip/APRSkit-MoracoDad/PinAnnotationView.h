//
//  PinAnnotationView.h
//  APRSkit-MoracoDad
//
//  Created by Stephen on 10/24/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>

@interface PinAnnotationView : MKPinAnnotationView {
@private	
    BOOL _isMoving;
    CGPoint _startLocation;
    CGPoint _originalCenter;
    MKMapView* _mapView;	
}

@property (nonatomic, assign) BOOL isMoving;
@property (nonatomic, assign) CGPoint startLocation;
@property (nonatomic, assign) CGPoint originalCenter;
@property (nonatomic, assign) MKMapView* mapView;

@end
