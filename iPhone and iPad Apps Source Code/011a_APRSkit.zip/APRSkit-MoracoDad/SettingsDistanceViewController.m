//
//  SettingsDistanceViewController.m
//  APRSkit-MoracoDad
//
//  Created by Stephen on 11/6/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import "SettingsDistanceViewController.h"
#import "APRSkit_MoracoDadAppDelegate.h"
#import "SettingsViewController.h"


@implementation SettingsDistanceViewController
@synthesize currDistance = m_strCurrDistance;
@synthesize vcDelegate = m_vcDelegate;


/*
- (IBAction)onActionFlip:(id)sender
{
	
}
 */

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	NSLog(@"SettingsDistanceViewController:viewDidLoad - ENTRY");
    [super viewDidLoad];
	
	// set our page title
	self.title = @"Distance From Me";
}

-(void)viewWillDisappear:(BOOL)animated
{
	// force switch back to top pge
	NSLog(@"SettingsDistanceViewController:viewWillDisappear - ENTRY");
	[self.vcDelegate onChildPageDone]; 
	[super viewWillDisappear:animated];
}

-(void)viewDidDisappear:(BOOL)animated
{
	NSLog(@"SettingsDistanceViewController:viewDidDisappear - ENTRY");
	[super viewDidDisappear:animated];
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[m_strCurrDistance release];
    [super dealloc];
}

#pragma mark -
#pragma mark UITableViewDelegate Methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;	
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return 7;  
}


- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
	return nil;
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
 	static NSString *CellIdentifier = @"OurCell";
	int nAppSelectedRow = indexPath.row;
	NSLog(@"SettingsDistanceViewController:cellForRowAtIndexPath(nAppSelectedRow=%d) - ENTRY",nAppSelectedRow);
	
	UITableViewCell *cell = [[tableView dequeueReusableCellWithIdentifier:CellIdentifier] retain];									
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
		
	}
	
	NSString  *strDistanceValue = [NSString stringWithFormat:@"%d", (nAppSelectedRow +1)*5 ];
	// Configure the new cell with desired title
	cell.textLabel.text = [NSString stringWithFormat:@"%@ Miles", strDistanceValue ];
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	
	if ([m_strCurrDistance isEqualToString:strDistanceValue]) {
		cell.accessoryType = UITableViewCellAccessoryCheckmark;
		m_ipLastSelectedIndexPath = indexPath;
	} else {
		cell.accessoryType = UITableViewCellAccessoryNone;
	}
	
	//NSLog(@"cell retainedCount=%d",[cell retainCount]);
    return cell;
}


// Override to support row selection in the table view.
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	
	int nAppSelectedRow = indexPath.row;
	NSLog(@"SettingsDistanceViewController:didSelectRowAtIndexPath:nAppSelectedRow=%d", nAppSelectedRow);
	
	[tableView cellForRowAtIndexPath:m_ipLastSelectedIndexPath].accessoryType = UITableViewCellAccessoryNone;
	[tableView cellForRowAtIndexPath:indexPath].accessoryType = UITableViewCellAccessoryCheckmark;
	m_ipLastSelectedIndexPath = indexPath;
	//m_cCheckedCell.accessoryType = UITableViewCellAccessoryNone;
	m_strCurrDistance = [NSString stringWithFormat:@"%d", (nAppSelectedRow +1)*5 ];

	// force switch back to top pge
	[self.vcDelegate onChildPageDone]; 
	
}



@end
