//
//  main.m
//  APRSkit-MoracoDad
//
//  Created by Stephen on 10/18/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
