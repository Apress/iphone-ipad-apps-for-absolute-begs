//
//  SettingsDistanceViewController.h
//  APRSkit-MoracoDad
//
//  Created by Stephen on 11/6/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SettingsViewController.h"

@interface SettingsDistanceViewController : UIViewController {
	NSString *m_strCurrDistance;
	NSIndexPath *m_ipLastSelectedIndexPath;
	SettingsViewController *m_vcDelegate;
}

@property (nonatomic, retain) NSString *currDistance;
@property (nonatomic, retain) SettingsViewController *vcDelegate;

@end
