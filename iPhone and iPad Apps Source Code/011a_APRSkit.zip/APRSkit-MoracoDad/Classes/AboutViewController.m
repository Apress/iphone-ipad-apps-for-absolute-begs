//
//  AboutViewController.m
//  MapAPRS-MoracoDad
//
//  Created by Stephen on 10/16/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import "AboutViewController.h"


@implementation AboutViewController
@synthesize btnInfo = m_btnInfo;

- (IBAction)onInfoPress:(id)sender
{
	// open an alert with just an OK button
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"APRS Kit" 
													message:@"an iPhone application\nby Stephen Moraco, KZ0Q\n\nProduced for\nthe CS201 Fall 2009 class\niPhone Application Programming\nin COCOA\nInstructor: Dr. Rory Lewis\n\nVersion 00.01"
												   delegate:self 
										  cancelButtonTitle:@"OK" 
										  otherButtonTitles: nil];
	[alert show];	
	[alert release];
}

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	NSLog(@"AboutViewController:viewDidLoad - ENTRY");
	
	// set our page title
	self.title = @"About";
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	NSLog(@"AboutViewController:didReceiveMemoryWarning - ENTRY");
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	NSLog(@"AboutViewController:viewDidUnload - ENTRY");
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
	NSLog(@"AboutViewController:dealloc - ENTRY");
    [super dealloc];
}


@end
