//
//  APRSkit_MoracoDadAppDelegate.h
//  APRSkit-MoracoDad
//
//  Created by Stephen on 10/18/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

@interface APRSkit_MoracoDadAppDelegate : NSObject <UIApplicationDelegate> {
    
    UIWindow *window;
    UINavigationController *navigationController;
	NSString *m_strCallSign;
	NSString *m_strSitePassword;
	NSString *m_strDistanceInMiles;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;
@property (nonatomic, copy) NSString *callSign;
@property (nonatomic, copy) NSString *sitePassword;
@property (nonatomic, copy) NSString *distanceInMiles;

@end

