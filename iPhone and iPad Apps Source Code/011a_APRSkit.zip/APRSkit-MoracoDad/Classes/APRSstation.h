//
//  APRSstation.h - INTERFACE
//  MapAPRS-MoracoDad
//
//  This class represents the details parsed from our
//  APRS traffic report for a single APRS-equipped 
//  amateur radio station
//
//  Created by Stephen on 10/17/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import <CoreLocation/CoreLocation.h>


@interface APRSstation : NSObject {
	NSString   *m_strCallsign;
	NSDate     *m_dtLastReport;
	NSNumber   *m_nDistanceInMiles;
	NSString   *m_strMsgURL;
	NSString   *m_strWxURL;
	NSString   *m_strTimeSinceLastReport;
	CLLocation *m_locPosition;
	int         m_nInstanceNbr;
}

@property(nonatomic, copy) NSString *callSign;
@property(nonatomic, copy) NSNumber *distanceInMiles;
@property(nonatomic, retain) NSDate *lastReport;
@property(nonatomic, copy) NSString *timeSinceLastReport;
@property(nonatomic, copy) NSString *msgURL;
@property(nonatomic, copy) NSString *wxURL;
@property(nonatomic, retain) CLLocation *position;

@end
