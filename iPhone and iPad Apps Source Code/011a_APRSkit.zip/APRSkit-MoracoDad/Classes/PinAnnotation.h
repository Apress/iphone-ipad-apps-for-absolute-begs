//
//  PinAnnotation.h
//  APRSkit-MoracoDad
//
//  Created by Stephen on 10/24/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>


@interface PinAnnotation : NSObject  <MKAnnotation, MKReverseGeocoderDelegate> {
@private
	CLLocationCoordinate2D _coordinate;
	NSString *_title;
	MKPlacemark *_placemark;
}

@property (nonatomic, retain) NSString *title;
@property (nonatomic, retain) MKPlacemark *placemark;

- (id)initWithCoordinate:(CLLocationCoordinate2D)coordinate title:(NSString*)title;
- (void)notifyCalloutInfo:(MKPlacemark *)placemark;
- (void)changeCoordinate:(CLLocationCoordinate2D)coordinate;

@end
