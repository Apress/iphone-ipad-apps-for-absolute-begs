//
//  APRSmapViewController.m
//  APRSkit-MoracoDad
//
//  Created by Stephen on 10/18/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import "APRSmapViewController.h"
#import "APRSstation.h"
#import "APRSstationAnnotation.h"
#import "APRSstationParser.h"
#import "APRSwebViewController.h"
#import "APRSkit_MoracoDadAppDelegate.h"

@implementation APRSmapViewController

@synthesize mapView = m_mvMap;
@synthesize webBrowserController = m_wvBrowserController;
@synthesize ctlMapTypeChooser = m_ctlMapTypeChooser;
@synthesize aiActivityInd  = m_aiActivityInd;



/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	NSLog(@"APRSmapViewController:viewDidLoad - ENTRY");
	m_bIsFirstLoad = YES;
	// set our page title
	self.title = @"Near Me";
	self.ctlMapTypeChooser.selectedSegmentIndex = 0;	// preset to street-map form
	[self.ctlMapTypeChooser addTarget:self action:@selector(selectMapMode:) forControlEvents:UIControlEventValueChanged];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
	NSLog(@"APRSmapViewController:didReceiveMemoryWarning - ENTRY");
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
	NSLog(@"APRSmapViewController:viewDidUnload - ENTRY");
}


- (void)dealloc {
	NSLog(@"APRSmapViewController:dealloc - ENTRY");
	[self.mapView release];
    [super dealloc];
}


#pragma mark -
#pragma mark UI Action Methods

-(IBAction)selectMapMode:(id)sender
{
	UISegmentedControl *scChooser = (UISegmentedControl *)sender;
	int nMapStyleIdx = [scChooser selectedSegmentIndex];
	NSLog(@"APRSmapViewController:selectMapMode - New Style=%d",nMapStyleIdx);
	
	switch (nMapStyleIdx) {
		case 0:
			self.mapView.mapType = MKMapTypeStandard;
			break;
		case 1:
			self.mapView.mapType = MKMapTypeSatellite;
			break;
		case 2:
			self.mapView.mapType = MKMapTypeHybrid;
			break;
		default:
			NSLog(@"APRSmapViewController:selectMapMode - Unknown Selection?!");
			break;
	}
}


#pragma mark -
#pragma mark MKMapViewDelegate

- (MKAnnotationView *)mapView:(MKMapView *)mapView 
            viewForAnnotation:(id <MKAnnotation>)annotation {
	
	NSLog(@"APRSmapViewController:viewForAnnotation - ENTRY");
	MKAnnotationView *view = nil;
	if(annotation != mapView.userLocation) {
		APRSstationAnnotation *asAnn = (APRSstationAnnotation*)annotation;
		view = [self.mapView dequeueReusableAnnotationViewWithIdentifier:@"stationLoc"];
		if(nil == view) {
			view = [[[MKPinAnnotationView alloc] initWithAnnotation:asAnn
													reuseIdentifier:@"stationLoc"] autorelease];
		}
		
		int nColorIdx = (asAnn.station.msgURL != nil) ? 1 : 0;
		nColorIdx |= (asAnn.station.wxURL != nil) ? 2 : 0;
		
		switch(nColorIdx)
		{
			case 1:
			case 2:
			case 3:
				[(MKPinAnnotationView *)view setPinColor:MKPinAnnotationColorPurple];
				[view setRightCalloutAccessoryView:[UIButton buttonWithType:UIButtonTypeDetailDisclosure]];
				break;
			default:
				[(MKPinAnnotationView *)view setPinColor:MKPinAnnotationColorRed];
				break;
				
		}
		
		NSRange rngSearchResult = [asAnn.station.callSign rangeOfString:@"kz0q" options:NSCaseInsensitiveSearch];
		if(rngSearchResult.location != NSNotFound)
		{
			[(MKPinAnnotationView *)view setPinColor:MKPinAnnotationColorGreen];
		}		
		
		[(MKPinAnnotationView *)view setAnimatesDrop:YES];
		[view setCanShowCallout:YES];
		
	} else {
		
		if(m_asParser == nil)
		{
			m_asParser = [APRSstationParser newAPRSstationParser];
			m_asParser.delegate = self;
		}
		else
		{
			NSLog(@"APRSmapViewController:viewForAnnotation  ReUSING Parser?!!");
		}
		
		// enable our parsing ind.
		[self.aiActivityInd startAnimating];
		[m_asParser getStationData];
		// THREADED don't do this!  [m_asParser release];
	}
	
	return view;
}

- (void)mapView:(MKMapView *)mapView 
 annotationView:(MKAnnotationView *)view 
calloutAccessoryControlTapped:(UIControl *)control {
	if(self.webBrowserController == nil)
	{
		self.webBrowserController = [[APRSwebViewController alloc] initWithNibName:@"APRSwebView" bundle:nil];
	}
	APRSstationAnnotation *asAnn = (APRSstationAnnotation *)[view annotation];
	NSURL *url = nil;
	BOOL bAskingUser = NO;
	if(asAnn.station.wxURL != nil && asAnn.station.msgURL != nil)
	{
		m_strButton0url = asAnn.station.wxURL;
		m_strButton1url = asAnn.station.msgURL;
		// open a dialog with an OK and cancel button
		UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"Select Desired Station Detail"
																 delegate:self 
														cancelButtonTitle:@"Cancel" 
												   destructiveButtonTitle:nil 
														otherButtonTitles:@"Wx Reports", @"Recent Messages", nil];
		actionSheet.actionSheetStyle = UIActionSheetStyleBlackTranslucent;
		[actionSheet showInView:self.view]; // show from our table view (pops up in the middle of the table)
		[actionSheet release];
		bAskingUser = YES;
	}
	else if(asAnn.station.wxURL != nil)
	{
		url = [NSURL URLWithString:asAnn.station.wxURL];
	}
	else if(asAnn.station.msgURL != nil)
	{
		url = [NSURL URLWithString:asAnn.station.msgURL];
	}
	if(url != nil)
	{
		// set URL
		self.webBrowserController.pageURL = url;
		// switch to the selected view
		[self.navigationController pushViewController:self.webBrowserController animated:YES];
	}
	else if(bAskingUser)
	{
		// do nothing in this case...
		// set URL to nothing to slow page load
		self.webBrowserController.pageURL = nil;
		// switch to the selected view
		[self.navigationController pushViewController:self.webBrowserController animated:YES];
	}
	else 
	{
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"APRS Kit - Error" 
														message:@"No Details URL found..."
													   delegate:self 
											  cancelButtonTitle:@"OK" 
											  otherButtonTitles: nil];
		[alert show];	
		[alert release];
	}

}


#pragma mark -
#pragma mark Utilty Methods

- (void)recenterMap {
	NSLog(@"APRSmapViewController:recenterMap - ENTRY");
	// scan all annotations to determin geographical center...
	NSArray *coordinates = [self.mapView valueForKeyPath:@"annotations.coordinate"];
	CLLocationCoordinate2D maxCoord = {-90.0f, -180.0f};
	CLLocationCoordinate2D minCoord = {90.0f, 180.0f};
	CLLocationCoordinate2D userLocationCoord = self.mapView.userLocation.coordinate;
	for(NSValue *value in coordinates) {
		CLLocationCoordinate2D coord = {0.0f, 0.0f};
		[value getValue:&coord];
		if(userLocationCoord.latitude != coord.latitude ||
		   userLocationCoord.longitude != coord.longitude)
		{
			if(coord.longitude > maxCoord.longitude) {
				maxCoord.longitude = coord.longitude;
			}
			if(coord.latitude > maxCoord.latitude) {
				maxCoord.latitude = coord.latitude;
			}
			if(coord.longitude < minCoord.longitude) {
				minCoord.longitude = coord.longitude;
			}
			if(coord.latitude < minCoord.latitude) {
				minCoord.latitude = coord.latitude;
			}
		}
	}
	// now calculate region of map to display
	MKCoordinateRegion region = {{0.0f, 0.0f}, {0.0f, 0.0f}};
	region.center.longitude = (minCoord.longitude + maxCoord.longitude) / 2.0;
	region.center.latitude = (minCoord.latitude + maxCoord.latitude) / 2.0;
	region.span.longitudeDelta = maxCoord.longitude - minCoord.longitude;
	region.span.latitudeDelta = maxCoord.latitude - minCoord.latitude;
	[self.mapView setRegion:region animated:YES];  
	NSLog(@"APRSmapViewController:recenterMap - EXIT");
}

#pragma mark -
#pragma mark APRSStationParserDelegate


- (void)addAPRSstation:(APRSstation *)newStation
{
	NSLog(@"APRSmapViewController:addAPRSstation (%@) - ENTRY",newStation.callSign);
	APRSkit_MoracoDadAppDelegate *appDelegate = (APRSkit_MoracoDadAppDelegate *)[[UIApplication sharedApplication] delegate];
	NSString *strCurrDistanceInMiles = appDelegate.distanceInMiles;
	NSScanner *ssParser = [NSScanner scannerWithString:strCurrDistanceInMiles];
	float fDistanceInMiles; 
	[ssParser scanFloat:&fDistanceInMiles];
	if([self.mapView.userLocation.location getDistanceFrom:newStation.position] < fDistanceInMiles * 5280.0f / 3.0f) {
		APRSstationAnnotation *newAnn = [APRSstationAnnotation annotationWithStation:newStation];
		[self.mapView addAnnotation:newAnn];
	}
}

- (void)parserFinished
{
	NSLog(@"PARSER ended, recentering map");
	
	// enable our parsing ind.
	[self.aiActivityInd stopAnimating];
	
	//[m_asParser release];
	//m_asParser = nil;
	
	// ensure we only center on first load...
	if(m_bIsFirstLoad)
	{
		[self recenterMap];
		m_bIsFirstLoad = NO;
	}
}

#pragma mark -
#pragma mark UIActionSheetDelegate methods

-(void)actionSheet:(UIActionSheet *)sendingSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
	m_nButtonPressed = buttonIndex;
	NSLog(@"actionSheet:clickedButtonAtIndex:%d",buttonIndex);
	if(m_nButtonPressed != -1)
	{
		switch (m_nButtonPressed) {
			case 0:
				{
					NSURL *url = [NSURL URLWithString:m_strButton0url];
					// set URL
					self.webBrowserController.pageURL = url;
					[self.webBrowserController viewWillAppear:YES];
				}
				break;
			case 1:
				{
					NSURL *url = [NSURL URLWithString:m_strButton1url];
					// set URL
					self.webBrowserController.pageURL = url;
					[self.webBrowserController viewWillAppear:YES];
				}
				break;
			default:
				break;
		}
	}
}

@end
