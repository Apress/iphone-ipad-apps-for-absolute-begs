//
//  AboutViewController.h
//  MapAPRS-MoracoDad
//
//  Created by Stephen on 10/16/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface AboutViewController : UIViewController {
	UIButton *m_btnInfo;
}

@property (nonatomic, retain) IBOutlet UIButton *btnInfo;

- (IBAction)onInfoPress:(id)sender;

@end
