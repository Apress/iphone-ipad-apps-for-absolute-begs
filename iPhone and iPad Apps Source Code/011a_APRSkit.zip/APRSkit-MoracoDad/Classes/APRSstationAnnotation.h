//
//  APRSstationAnnotation.h
//  MapAPRS-MoracoDad
//
//  Created by Stephen on 10/17/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

@class APRSstation;

@interface APRSstationAnnotation : NSObject <MKAnnotation> {
	CLLocationCoordinate2D m_lcCoordinate;
	NSString *m_strTitle;
	NSString *m_strSubtitle;
	APRSstation *m_asStation;
}

@property(nonatomic, assign) CLLocationCoordinate2D coordinate;
@property(nonatomic, copy) NSString *title;
@property(nonatomic, copy) NSString *subtitle;
@property(nonatomic, retain) APRSstation *station;

+ (id)annotationWithStation:(APRSstation *)station;
- (id)initWithStation:(APRSstation *)station;

@end
