//
//  LoadingViewController.h
//  APRSkit-MoracoDad
//
//  Created by Stephen on 10/18/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface LoadingViewController : UIViewController {

}

@end
