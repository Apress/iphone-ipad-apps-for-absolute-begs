//
//  SettingsViewController.m
//  MapAPRS-MoracoDad
//
//  Created by Stephen on 10/15/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import "SettingsViewController.h"
#import "APRSkit_MoracoDadAppDelegate.h"
#import "SettingsDistanceViewController.h"


@interface SettingsViewController (PrivateDataAndMethods)
// Private data
SettingsDistanceViewController *m_vcSelectDistance;
NSIndexPath *m_ipActiveRow;
UITableView *m_tvActiveTable;
BOOL m_bIsResetToFrontPage;

// Private methods
- (IBAction)onActionFlip;

@end

#pragma mark -
@implementation SettingsViewController


@synthesize txfldCallSign = m_txfldCallSign;
@synthesize txfldSitePassword = m_txfldSitePassword;
@synthesize currDistance = m_strCurrDistance;

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
	NSLog(@"SettingsViewController:loadView - ENTRY");
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	NSLog(@"SettingsViewController:viewDidLoad - ENTRY");
    [super viewDidLoad];
	
	// set our page title
	self.title = @"Settings";
	
	m_bHaveNewValue = NO;
	m_bIsResetToFrontPage  = YES;
	//set our initial field values
	APRSkit_MoracoDadAppDelegate *appDelegate = (APRSkit_MoracoDadAppDelegate *)[[UIApplication sharedApplication] delegate];
	self.txfldCallSign.text	= appDelegate.callSign;
	self.txfldSitePassword.text	= appDelegate.sitePassword;
	m_strCurrDistance = appDelegate.distanceInMiles;
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	NSLog(@"SettingsViewController:didReceiveMemoryWarning - ENTRY");
	
	// Release any cached data, images, etc that aren't in use.
}

-(void)viewWillAppear:(BOOL)animated
{
	NSLog(@"SettingsViewController:viewWillAppear - ENTRY");
	m_bIsResetToFrontPage = YES;
	[self onActionFlip];
	[super viewWillAppear:animated];
}

-(void)viewDidAppear:(BOOL)animated
{
	NSLog(@"SettingsViewController:viewDidAppear - ENTRY");
	[super viewDidAppear:animated];
}

-(void)viewWillDisappear:(BOOL)animated
{
	// force switch back to top pge
	NSLog(@"SettingsViewController:viewWillDisappear - ENTRY");
	[self onChildPageDone]; 
	[super viewWillDisappear:animated];
}

-(void)viewDidDisappear:(BOOL)animated
{
	NSLog(@"SettingsViewController:viewDidDisappear - ENTRY");
	[super viewDidDisappear:animated];
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
	NSLog(@"SettingsViewController:viewDidUnload - ENTRY");
}


- (void)dealloc {
	NSLog(@"SettingsViewController:dealloc - ENTRY");
	[m_txfldCallSign release];
	[m_txfldSitePassword release];
	[m_vcSelectDistance release];
	[m_strCurrDistance release];
	
    [super dealloc];
}



#pragma mark -
#pragma mark UITextFieldDelegate Methods

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	APRSkit_MoracoDadAppDelegate *appDelegate = (APRSkit_MoracoDadAppDelegate *)[[UIApplication sharedApplication] delegate];
	if(textField == self.txfldCallSign)
	{
		appDelegate.callSign = textField.text;
	} else if (textField == self.txfldSitePassword) {
		appDelegate.sitePassword = textField.text;
	}
	
	// the user pressed the "Done" button, so dismiss the keyboard
	[textField resignFirstResponder];
	return YES;
}

- (IBAction)onEditingDidEnd:(id)sender
{
	UITextField *textField = (UITextField *)sender;
	// the user pressed the "Done" button, so dismiss the keyboard
	[textField resignFirstResponder];
	//return YES;
}

#pragma mark -
#pragma mark Child Page Navigation Support Methods

-(void)onChildPageDone
{
	NSLog(@"SettingsViewController:onChildPageDone - ENTRY");
	if([m_strCurrDistance isEqual:m_vcSelectDistance.currDistance])
	{
		m_bHaveNewValue = NO;
	}
	else
	{
		m_bHaveNewValue = YES;
	}
	m_bIsResetToFrontPage  = YES;
	[self onActionFlip];
}


- (IBAction)onActionFlip
{
	NSLog(@"SettingsViewController:onActionFlip - ENTRY");
	[UIView setAnimationDelegate:self];
	[UIView setAnimationDidStopSelector:@selector(animationDidStop:animationIDfinished:finished:context:)];
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.75];
	
	if(m_vcSelectDistance == nil)
	{
		m_vcSelectDistance = [[SettingsDistanceViewController alloc] initWithNibName:@"SettingsDistanceView" bundle:[NSBundle mainBundle]];
		m_vcSelectDistance.vcDelegate = self;
	}
	
	[UIView setAnimationTransition:([[m_vcSelectDistance view] superview] ?
									UIViewAnimationTransitionFlipFromLeft : UIViewAnimationTransitionFlipFromRight)
						   forView:self.view cache:YES];
	
	
	BOOL bIsSettingsDistanceActive = YES;
	if ([[m_vcSelectDistance view] superview])
	{
		if(m_bHaveNewValue)
		{
			// retrieve the newly selected value
			self.currDistance = m_vcSelectDistance.currDistance;
			// indicate that we've got it now...
			m_bHaveNewValue = NO;
			// and save our new setting
			APRSkit_MoracoDadAppDelegate *appDelegate = (APRSkit_MoracoDadAppDelegate *)[[UIApplication sharedApplication] delegate];
			appDelegate.distanceInMiles = self.currDistance;
		}
		[[m_vcSelectDistance view] removeFromSuperview];
		bIsSettingsDistanceActive = NO;
		m_vcSelectDistance = nil;
	}
	else
	{
		if(!m_bIsResetToFrontPage)
		{
			// tell page its starting value
			m_vcSelectDistance.currDistance	= m_strCurrDistance;
			[self.view addSubview:[m_vcSelectDistance view]];
		}
	}
	
	[UIView commitAnimations];
	
	// if we are returning from child page, reset row selection
	//  and then update row display...
	if (bIsSettingsDistanceActive == NO)
	{
		// deselect row
		[m_tvActiveTable deselectRowAtIndexPath:m_ipActiveRow animated:YES];
		// update row label with latest value
		[[m_tvActiveTable cellForRowAtIndexPath:m_ipActiveRow] detailTextLabel].text = [NSString stringWithFormat:@"%@ Miles", m_strCurrDistance];
	}
}



#pragma mark -
#pragma mark UITableViewDelegate Methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return tableView.tag;	// our values happen to be 0 and 1 nicely!
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return 1;  
}


- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
	return nil;
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
 	static NSString *CellIdentifier = @"OurCell";
	
	UITableViewCell *cell = [[tableView dequeueReusableCellWithIdentifier:CellIdentifier] retain];									
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier] autorelease];
		
	}
	
	// Configure the new cell with desired title
	cell.textLabel.text = @"Distance From Me";
	
	// and reflect our current distance selection in the detailTitle text
	cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ Miles", m_strCurrDistance];
	//[appDelegate release];
	
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	NSLog(@"cell retainedCount=%d",[cell retainCount]);
    return cell;
}


// Override to support row selection in the table view.
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	
	int nAppSelectedRow = indexPath.row;
	NSLog(@"SettingsViewController:didSelectRowAtIndexPath:nAppSelectedRow=%d", nAppSelectedRow);
	
	bool bShowDistanceView = NO;	// id we haven't loaded this view yet, do so...
	switch (nAppSelectedRow) 
	{
		case 0:
			bShowDistanceView = YES;
			break;
		default:
			break;
	}
	
	if(bShowDistanceView)
	{
		// save off our selected row details so that we can clear the selection
		m_ipActiveRow = indexPath;
		m_tvActiveTable = tableView;
		// indicate that we are going to a child page
		m_bIsResetToFrontPage  = NO;
		// and let's flip over this!
		[self onActionFlip];	
	}
	
}




@end
