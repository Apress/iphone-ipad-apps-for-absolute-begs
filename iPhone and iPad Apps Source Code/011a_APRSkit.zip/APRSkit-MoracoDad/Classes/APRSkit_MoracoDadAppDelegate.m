//
//  APRSkit_MoracoDadAppDelegate.m
//  APRSkit-MoracoDad
//
//  Created by Stephen on 10/18/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import "APRSkit_MoracoDadAppDelegate.h"
#import "RootViewController.h"


@implementation APRSkit_MoracoDadAppDelegate

@synthesize window;
@synthesize navigationController;
@synthesize callSign = m_strCallSign;
@synthesize sitePassword = m_strSitePassword;
@synthesize distanceInMiles = m_strDistanceInMiles;


#pragma mark -
#pragma mark Keys Used for Application Settings Access

NSString *kCallSignKey			= @"MapAPRS-Callsign";
NSString *kSitePasswordKey		= @"MapAPRS-SitePassword";
NSString *kDistanceInMilesKey	= @"MapAPRS-DistanceInMiles";
NSString *strEmptyString		= @"";


#pragma mark -
#pragma mark Application lifecycle

- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
	NSLog(@"MapAPRS_MoracoDadAppDelegate:applicationDidFinishLaunching - ENTRY");
    // Override point for customization after app launch    
	
	[window addSubview:[navigationController view]];
    [window makeKeyAndVisible];
	
	// preload our applcation defaults
	NSUserDefaults *upSettings = [NSUserDefaults standardUserDefaults];
	NSString *strDefaultCallsign = [upSettings stringForKey:kCallSignKey];
	if(strDefaultCallsign == nil)
	{
		strDefaultCallsign = strEmptyString;
	}
	self.callSign = strDefaultCallsign;
	//[strDefaultCallsign release];
	
	NSString *strDefaultSitePassword = [upSettings stringForKey:kSitePasswordKey];
	if(strDefaultSitePassword == nil)
	{
		strDefaultSitePassword = strEmptyString;
	}
	self.sitePassword = strDefaultSitePassword;
	
	NSString *strDefaultDistanceInMiles = [upSettings stringForKey:kDistanceInMilesKey];
	if(strDefaultDistanceInMiles == nil)
	{
		strDefaultDistanceInMiles = @"30";
	}
	self.distanceInMiles = strDefaultDistanceInMiles;
	//[strDefaultSitePassword release];
	// INCORRECT DECR [upSettings release];
}

-(void)SavePeferences
{
	NSLog(@"APRSkit_MoracoDadAppDelegate:SavePreferences - ENTRY");
	// Save data if appropriate
	NSUserDefaults *upSettings = [NSUserDefaults standardUserDefaults];
	[upSettings setObject:self.callSign forKey:kCallSignKey];
	[upSettings setObject:self.sitePassword forKey:kSitePasswordKey];
	[upSettings setObject:self.distanceInMiles forKey:kDistanceInMilesKey];
	[upSettings synchronize];
	// INCORRECT DECR [upSettings release];
}

- (void)applicationWillResignActive:(UIApplication *)application
{
	// Save data ...
	NSLog(@"APRSkit_MoracoDadAppDelegate:applicationWillResignActive - ENTRY");
	// Save data as we exit
	[self SavePeferences];
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
	// Save data ...
	NSLog(@"APRSkit_MoracoDadAppDelegate:applicationDidBecomeActive - ENTRY");
	// UNDONE are pref's still loaded???? maybe load here?
}


- (void)applicationWillTerminate:(UIApplication *)application {
	// Save data if appropriate
	NSLog(@"APRSkit_MoracoDadAppDelegate:applicationWillTerminate - ENTRY");
	// Save data as we exit
	[self SavePeferences];
}


#pragma mark -
#pragma mark Memory management

- (void)dealloc {
	[navigationController release];
	[window release];
	[self.callSign release];
	[self.sitePassword release];
	[super dealloc];
}


@end

