//
//  SettingsViewController.h
//  MapAPRS-MoracoDad
//
//  Created by Stephen on 10/15/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingsViewController : UIViewController <UITextFieldDelegate, UITableViewDelegate> {
	UITextField	*m_txfldCallSign;
	UITextField	*m_txfldSitePassword;
	NSString *m_strCurrDistance;
	bool m_bHaveNewValue;
}

@property (nonatomic, retain) IBOutlet UITextField	*txfldCallSign;
@property (nonatomic, retain) IBOutlet UITextField	*txfldSitePassword;
@property (nonatomic, retain) NSString	*currDistance;


- (IBAction)onEditingDidEnd:(id)sender;
-(void)onChildPageDone;

@end
