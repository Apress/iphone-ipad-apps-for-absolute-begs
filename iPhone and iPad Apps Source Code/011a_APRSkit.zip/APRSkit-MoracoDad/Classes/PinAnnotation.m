//
//  PinAnnotation.m
//  APRSkit-MoracoDad
//
//  Created by Stephen on 10/24/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import "PinAnnotation.h"


@implementation PinAnnotation

@synthesize coordinate = _coordinate; // property declared in MKAnnotation.h
@synthesize title = _title;
@synthesize placemark = _placemark;


#pragma mark -
#pragma mark PinAnnotation implementation


- (id)initWithCoordinate:(CLLocationCoordinate2D)coordinate title:(NSString*)title {
	if (self = [super init]) {
		[self changeCoordinate:coordinate];		
		self.title = [title retain];
		self.placemark = nil;
	}
	return self;
}

#pragma mark -
#pragma mark MKAnnotation Methods

- (NSString *)subtitle {
	NSString* subtitle = nil;
	
	if (self.placemark) {
		subtitle = [NSString stringWithFormat:@"%@, %@", self.placemark.administrativeArea, self.placemark.country];
	} else {
		subtitle = [NSString stringWithFormat:@"%lf, %lf", self.coordinate.latitude, self.coordinate.longitude];
	}
	
	return subtitle;
}

#pragma mark -
#pragma mark Change coordinate

- (void)changeCoordinate:(CLLocationCoordinate2D)coordinate {
	_coordinate = coordinate;
	
	// Try to reverse geocode here
	MKReverseGeocoder *reverseGeocoder = [[MKReverseGeocoder alloc] initWithCoordinate:self.coordinate];
	reverseGeocoder.delegate = self;
	[reverseGeocoder start];	
}

#pragma mark -
#pragma mark MKReverseGeocoderDelegate methods

- (void)reverseGeocoder:(MKReverseGeocoder *)geocoder didFindPlacemark:(MKPlacemark *)placemark {
	[self notifyCalloutInfo:placemark];
	[geocoder release];
}

- (void)reverseGeocoder:(MKReverseGeocoder *)geocoder didFailWithError:(NSError *)error {
	[self notifyCalloutInfo:nil];
	[geocoder release];
}

#pragma mark -
#pragma mark MKAnnotationView Notification

- (void)notifyCalloutInfo:(MKPlacemark *)placemark {
	[self willChangeValueForKey:@"subtitle"]; // Workaround for SDK 3.0, otherwise callout info won't update.
	self.placemark = placemark;
	[self didChangeValueForKey:@"subtitle"]; // Workaround for SDK 3.0, otherwise callout info won't update.
	
	[[NSNotificationCenter defaultCenter] postNotification:[NSNotification notificationWithName:@"MKAnnotationCalloutInfoDidChangeNotification" object:self]];
}

#pragma mark -
#pragma mark Memory Management

- (void)dealloc {
	[_title release], _title = nil;
	[_placemark release], _placemark = nil;
	[super dealloc];
}

@end

