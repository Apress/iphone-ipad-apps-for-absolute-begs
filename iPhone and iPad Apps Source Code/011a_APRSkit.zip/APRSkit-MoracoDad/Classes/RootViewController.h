//
//  RootViewController.h
//  APRSkit-MoracoDad
//
//  Created by Stephen on 10/18/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

@interface RootViewController : UITableViewController {
	UIBarButtonItem *m_btnAction;
	UIBarButtonItem *m_btnDone;
	
	UIViewController *m_vcCurrentViewController;
	UIViewController *m_vcSettingsViewController;
	
	UITableView *m_tvTableView;
	NSIndexPath *m_ipViewedRow;
}

@property (nonatomic,retain) UIViewController *currentViewController;
@property (nonatomic,retain) UIViewController *settingsViewController;
@property (nonatomic, retain) IBOutlet UIBarButtonItem *btnAction;
@property (nonatomic, retain) IBOutlet UIBarButtonItem *btnDone;

- (IBAction)onActionFlip:(id)sender;


@end
