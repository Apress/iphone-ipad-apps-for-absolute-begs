//
//  APRSwebViewController.m
//  APRSkit-MoracoDad
//
//  Created by Stephen on 10/23/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import "APRSwebViewController.h"


@implementation APRSwebViewController

@synthesize pageURL = m_urlPageAddress;

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/

// am overiding to cause navigation to the desired page 
-(void)viewWillAppear:(BOOL)animated
{
	UIWebView *wvWebView = (UIWebView *)self.view;
	if(self.pageURL != nil)
	{
		// each time the view appears make sure we are using the latest requested URL
		[wvWebView loadRequest:[[NSURLRequest alloc] initWithURL:self.pageURL]];
	}
	else
	{
		// clear our previous page
		NSURL *url = [NSURL URLWithString:@"about:blank"];
		[wvWebView loadRequest:[[NSURLRequest alloc] initWithURL:url]];
		// CRASHES [url release];
	}
}

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return YES;
}


- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

#pragma mark -
#pragma mark UIWebViewDelegate methods

-(void)webViewDidStartLoad
{
	[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
}

-(void)webViewDidEndLoad
{
	[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
}

-(void)webView:(UIWebView *)webView DidFailLoadWithError:(NSError *)error
{
	[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;

	NSString *strErrorMsg = [NSString stringWithFormat:@"Page load failed. Error=%@", [error localizedDescription]];
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"APRS Kit - Error" 
													message:strErrorMsg
												   delegate:self 
										  cancelButtonTitle:@"OK" 
										  otherButtonTitles: nil];
	[alert show];	
	[alert release];
	// ANLY says not ours to release!!!  [strErrorMsg release];
}


@end
