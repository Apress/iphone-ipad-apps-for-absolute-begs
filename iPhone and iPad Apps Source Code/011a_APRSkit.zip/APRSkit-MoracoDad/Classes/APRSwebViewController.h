//
//  APRSwebViewController.h
//  APRSkit-MoracoDad
//
//  Created by Stephen on 10/23/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface APRSwebViewController : UIViewController <UIWebViewDelegate> {
	NSURL *m_urlPageAddress;
}

@property (nonatomic, retain) NSURL *pageURL;


@end
