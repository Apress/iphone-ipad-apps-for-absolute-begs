//
//  APRSstationAnnotation.m
//  MapAPRS-MoracoDad
//
//  Created by Stephen on 10/17/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import "APRSstationAnnotation.h"
#import "APRSstation.h"

@implementation APRSstationAnnotation

@synthesize coordinate = m_lcCoordinate;
@synthesize title = m_strTitle;
@synthesize subtitle = m_strSubtitle;
@synthesize station = m_asStation;

+ (id)annotationWithStation:(APRSstation *)station
{
	return [[[[self class] alloc] initWithStation:station] autorelease];
}

- (id)initWithStation:(APRSstation *)station
{
	self = [super init];
	if(nil != self) {
		NSString *msgToken = (station.msgURL == nil) ? @"": @" msg";
		NSString *wxToken = (station.wxURL == nil) ? @"": @" wx";
		self.title = [NSString stringWithFormat:@"%@%@%@", station.callSign, msgToken, wxToken];
		[msgToken release];
		[wxToken release];
		NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
		[formatter setDateFormat:@"MMM dd, yyyy HH:mm"];
		self.subtitle = [NSString stringWithFormat:@"%@ - %1.1f miles", 
						 [formatter stringFromDate:station.lastReport], 
						 station.distanceInMiles.floatValue];
		[formatter release];
		self.coordinate = station.position.coordinate;
		self.station = station;
		NSLog(@"APRSstationAnnotation:initWithStation=%@",self.title);
	}
	return self;
}

- (void) dealloc {
	NSLog(@"APRSstationAnnotation:dealloc=%@",self.title);
	[self.title release];
	[self.subtitle release];
	[self.station release];
	[super dealloc];
}


@end
