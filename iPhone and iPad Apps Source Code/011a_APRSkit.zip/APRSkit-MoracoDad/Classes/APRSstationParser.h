//
//  APRSstationParser.h
//  MapAPRS-MoracoDad
//
//  Created by Stephen on 10/17/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import <Foundation/Foundation.h>

@class APRSstation;
@protocol APRSStationParserDelegate;

@interface APRSstationParser : NSObject {
	APRSstation       *m_asCurrentSation;
	NSMutableString   *m_strPropertyValue;
	id<APRSStationParserDelegate> m_aspDelegate;
	NSOperationQueue  *m_oqRetrieverQueue;
	
	// items for column-based parsing
	NSString          *m_strColumnName;
	int                m_nColumnNbr;
	BOOL	           m_bIsProcessingTable;
	NSNumber          *m_nLatitude;
	NSDate            *m_dtTimeOfDataFetch;
}

@property(nonatomic, retain) APRSstation *currentStation;
@property(nonatomic, retain) NSMutableString *propertyValue;
@property(nonatomic, assign) id<APRSStationParserDelegate> delegate;
@property(nonatomic, retain) NSOperationQueue *retrieverQueue;

+ (id)newAPRSstationParser;
- (void)getStationData;

@end

@protocol APRSStationParserDelegate <NSObject>

- (void)addAPRSstation:(APRSstation *)newStation;
- (void)parserFinished;

@end
