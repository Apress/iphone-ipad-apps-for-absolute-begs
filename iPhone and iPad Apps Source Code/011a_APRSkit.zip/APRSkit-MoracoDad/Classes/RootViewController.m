//
//  RootViewController.m
//  APRSkit-MoracoDad
//
//  Created by Stephen on 10/18/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import "RootViewController.h"
#import "SettingsViewController.h"
#import "APRSmapViewController.h"
#import "AboutViewController.h"
#import "LoadingViewController.h"
#import "APRSpinViewController.h"


@implementation RootViewController

@synthesize currentViewController = m_vcCurrentViewController;
@synthesize settingsViewController = m_vcSettingsViewController;
@synthesize btnAction = m_btnAction;
@synthesize btnDone = m_btnDone;


/*
- (void)viewDidLoad {
    [super viewDidLoad];

    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}
*/

/*
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}
*/
/*
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}
*/
/*
- (void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
}
*/
/*
- (void)viewDidDisappear:(BOOL)animated {
	[super viewDidDisappear:animated];
}
*/

/*
 // Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Return YES for supported orientations.
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
 */

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
	NSLog(@"RootViewController:didReceiveMemoryWarning - ENTRY");
}

- (void)viewDidUnload {
	// Release anything that can be recreated in viewDidLoad or on demand.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


#pragma mark -
#pragma mark Settings Dialog switcher

- (IBAction)onActionFlip:(id)sender
{
	[UIView setAnimationDelegate:self];
	[UIView setAnimationDidStopSelector:@selector(animationDidStop:animationIDfinished:finished:context:)];
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.75];
	
	[UIView setAnimationTransition:([[self.settingsViewController view] superview] ?
									UIViewAnimationTransitionFlipFromLeft : UIViewAnimationTransitionFlipFromRight)
			forView:self.tableView cache:YES];
	
	if(self.settingsViewController == nil)
	{
		self.settingsViewController = [[SettingsViewController alloc] initWithNibName:@"SettingsView" bundle:[NSBundle mainBundle]];
	}
	
	BOOL bIsSettingsActive = YES;
	if ([[self.settingsViewController view] superview])
	{
		// fake the proper notification... <this isn't being called!!!>
		[self.settingsViewController viewWillDisappear:YES];
		[[self.settingsViewController view] removeFromSuperview];
		bIsSettingsActive = NO;
	}
	else
	{
		[self.tableView addSubview:[self.settingsViewController view]];
	}
	
	[UIView commitAnimations];
	
	// adjust our done/info buttons accordingly
	if (bIsSettingsActive == YES)
	{
		self.navigationItem.rightBarButtonItem = self.btnDone;
	}
	else
	{
		self.navigationItem.rightBarButtonItem = self.btnAction;
	}
}


#pragma mark -
#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 3;	// set to 4 to enable display of default startup screen (to capture splash)
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    
	int nViewSelectedIdx = indexPath.row;
	
	// Configure the cell.
	switch (nViewSelectedIdx) {
		case 0:  // APRS map
			cell.textLabel.text = @"Stations Near Me";
			break;
		case 1:  // About Page
			cell.textLabel.text = @"About";
			break;
		case 2:  // APRS pin i/f
			cell.textLabel.text = @"Report my QTH";
			break;
		case 3:  // Default
			cell.textLabel.text = @"Startup Splash (for screen capture)";
			break;
		default:
			NSLog(@"(DBG) Bad Row Index: nViewSelectedIdx=%d",nViewSelectedIdx);
			break;
	}
	
	// show our arrow, too
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	
    return cell;
}




// Override to support row selection in the table view.
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

    // Navigation logic may go here -- for example, create and push another view controller.
	int nViewSelectedIdx = indexPath.row;
	
	self.currentViewController = nil;
	self.title = @"APRS";
    
	// Switch to the desired view
	switch (nViewSelectedIdx) {
		case 0:  // APRS map
			self.currentViewController = [[APRSmapViewController alloc] initWithNibName:@"APRSmapView" bundle:[NSBundle mainBundle]];
			break;
		case 1:  // About Page
			self.currentViewController = [[AboutViewController alloc] initWithNibName:@"AboutView" bundle:[NSBundle mainBundle]];
			break;
		case 2:  // APRS set location Map
			self.currentViewController = [[APRSpinViewController alloc] initWithNibName:@"APRSpinView" bundle:[NSBundle mainBundle]];
			break;
		case 3:
			self.currentViewController = [[LoadingViewController alloc] initWithNibName:@"LoadingView" bundle:[NSBundle mainBundle]];
			self.title = @"";
			break;
		default:
			NSLog(@"(DBG) Bad Row Index: nViewSelectedIdx=%d",nViewSelectedIdx);
			break;
	}
	
	// if we've created a new viewController, switch to it!
	if(self.currentViewController != nil)
	{
		m_tvTableView = tableView;
		m_ipViewedRow = indexPath;

		// switch to the selected view
		[self.navigationController pushViewController:self.currentViewController animated:YES];
	}
}



/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/


/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source.
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }   
}
*/


/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/


/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


@end

