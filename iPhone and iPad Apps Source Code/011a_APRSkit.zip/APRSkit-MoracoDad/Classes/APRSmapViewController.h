//
//  APRSmapViewController.h
//  APRSkit-MoracoDad
//
//  Created by Stephen on 10/18/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "APRSstationParser.h"
#import "APRSwebViewController.h"

@interface APRSmapViewController : UIViewController <MKMapViewDelegate, APRSStationParserDelegate, UIActionSheetDelegate> {
	MKMapView *m_mvMap;
	APRSwebViewController *m_wvBrowserController;
	APRSstationParser *m_asParser;
	NSInteger m_nButtonPressed;
	NSString *m_strButton0url;
	NSString *m_strButton1url;
	BOOL m_bIsFirstLoad;
	UISegmentedControl *m_ctlMapTypeChooser;
	UIActivityIndicatorView *m_aiActivityInd;
}

@property (nonatomic, retain) IBOutlet MKMapView *mapView;
@property (nonatomic, retain) APRSwebViewController *webBrowserController;
@property (nonatomic, retain) IBOutlet UISegmentedControl *ctlMapTypeChooser;
@property (nonatomic, retain) IBOutlet UIActivityIndicatorView *aiActivityInd;


-(IBAction)selectMapMode:(id)sender;

@end
