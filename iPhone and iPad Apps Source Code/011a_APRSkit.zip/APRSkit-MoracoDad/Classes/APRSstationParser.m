//
//  APRSstationParser.m
//  MapAPRS-MoracoDad
//
//  Created by Stephen on 10/17/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import "APRSstationParser.h"
#import "APRSstation.h"
#import "APRSkit_MoracoDadAppDelegate.h"


@implementation APRSstationParser

@synthesize currentStation = m_asCurrentSation;
@synthesize propertyValue = m_strPropertyValue;
@synthesize delegate = m_aspDelegate;
@synthesize retrieverQueue = m_oqRetrieverQueue;

+ (id)newAPRSstationParser
{
	// POTENTIAL LEAK ignored!! is class factory method!
	return [[[self class] alloc] init];
}

- (void)getStationData
{
	NSLog(@"APRSstationParser:getStationData - ENTRY  ***\n\n");
	SEL method = @selector(parseForData);
	NSInvocationOperation *op = [[NSInvocationOperation alloc] initWithTarget:self 
																	 selector:method 
																	   object:nil];
	[self.retrieverQueue addOperation:op];
	[op release];
}

- (NSOperationQueue *)retrieverQueue {
	if(nil == m_oqRetrieverQueue) {
		m_oqRetrieverQueue = [[NSOperationQueue alloc] init];
		m_oqRetrieverQueue.maxConcurrentOperationCount = 1;
	}
	return m_oqRetrieverQueue;
}

- (void) dealloc {
	NSLog(@"APRSstationParser:dealloc - ENTRY");
	
	[self.currentStation release];
	[self.propertyValue release];
	[self.delegate release];
	[self.retrieverQueue release];
	[m_strColumnName release];
	[m_nLatitude release];
	[m_dtTimeOfDataFetch release];
	
	[super dealloc];
}


#pragma mark -
#pragma mark Parser Toplevel Routine

static NSString *s_strFeedURLBaseString = @"http://www.findU.com/cgi-bin/map-near.cgi?call=";

// this method is fired by the operation created in
// getStationData so its on an alternate thread
- (BOOL)parseForData {
	BOOL bWasParseSuccessful = YES;
	
	m_bIsProcessingTable = false;	// tell our parser that we are not yet in the correct data
	
	// Retrieve the current callsign from our current settings
	APRSkit_MoracoDadAppDelegate *appDelegate = (APRSkit_MoracoDadAppDelegate *)[[UIApplication sharedApplication] delegate];
	NSString *strCurrCallsign = appDelegate.callSign;
	if(strCurrCallsign != nil && [strCurrCallsign length] == 0)
	{
		bWasParseSuccessful = NO;
	}
	else
	{
		// have callsign, let's do query and retrieve data
		NSString *strFullQueryURL =  [NSString stringWithFormat:@"%@%@", s_strFeedURLBaseString, strCurrCallsign];
		NSLog(@"parser reqeust URL= %@", strFullQueryURL);
		[strCurrCallsign release];
		
		// show querying network for data...
		[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
		
		
		NSURL *url = [NSURL URLWithString:strFullQueryURL];
		// INCORRECT DECR!!		[strFullQueryURL release];
		//
		// adapter to filter out bad meta tags in <HEAD></HEAD> sectiion
		//  along with all other findings...
		//
		
		// retrieve the text to process
		NSError *anError = nil;
		NSString *strQueryResults = [NSString stringWithContentsOfURL:url encoding:NSWindowsCP1250StringEncoding error:&anError];
		
		// show done-querying network...
		[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
		
		if(strQueryResults == nil)
		{
			NSLog(@"ERROR reading URL: message=[%@] url=[%@]", [anError localizedDescription],strFullQueryURL);
			bWasParseSuccessful = NO;
		}
		else
		{
			NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
			NSLog(@"SUCCESS, read data from server!");
			// show the our querying of network is complete
			// INCORRECT DECR!!		[url release];
			
			// set the date time of this data-read
			m_dtTimeOfDataFetch = [NSDate date];	// time now...
			
			NSString *strNoParaQueryResults = [strQueryResults stringByReplacingOccurrencesOfString:@"<p>" withString:@""];
			strNoParaQueryResults = [strNoParaQueryResults stringByReplacingOccurrencesOfString:@"<br>" withString:@""];
			
			NSArray *strQueryResultAr = [strNoParaQueryResults componentsSeparatedByString:@"\n"];
			// INCORRECT DECR!!  [strNoParaQueryResults release];
			// INCORRECT DECR!! [strQueryResults release];
			
			NSLog(@"FILTER: data in hand, now filtering...%d lines received",[strQueryResultAr count]);
			NSMutableArray *strFilteredQueryResultsAr = [[NSMutableArray alloc] init];
			
			NSEnumerator *eCurrentObject = [strQueryResultAr objectEnumerator];
			NSString *strCurrLine;
			while(strCurrLine = (NSString *)[eCurrentObject nextObject])
			{
				// filter out meta tags
				NSRange rngSearchResult = [strCurrLine rangeOfString:@"<meta" options:NSCaseInsensitiveSearch];
				if(rngSearchResult.location == NSNotFound)
				{
					// filter out image tags
					NSRange rngSearchResult = [strCurrLine rangeOfString:@"<img" options:NSCaseInsensitiveSearch];
					if(rngSearchResult.location == NSNotFound)
					{
						// the table tag lands on a partial line most of which is useless so replace it with a table opening tag
						NSRange rngSearchResult = [strCurrLine rangeOfString:@"<TABLE" options:NSCaseInsensitiveSearch];
						if(rngSearchResult.location == NSNotFound)
						{
							// a header line is the first in the table, remove it!
							NSRange rngSearchResult = [strCurrLine rangeOfString:@"<td> Call </td>" options:NSCaseInsensitiveSearch];
							if(rngSearchResult.location == NSNotFound)
							{
								[strFilteredQueryResultsAr addObject:strCurrLine];
							}
							else
							{
								NSLog(@"FILTER: removed %@",strCurrLine);
							}
						}
						else
						{
							[strFilteredQueryResultsAr addObject:@"<table>"];
						}
					}
					else
					{
						NSLog(@"FILTER: removed %@",strCurrLine);
						[strFilteredQueryResultsAr addObject:@"<table>"];
					}
				}
				else
				{
					NSLog(@"FILTER: removed %@",strCurrLine);
				}
			}
			// THIS CRASHES THE PARSER?????   [strQueryResultAr release];
			
			NSString *strQueryResult = [strFilteredQueryResultsAr componentsJoinedByString:@"\n"];
			NSLog(@"FILTER: filter complete, %d output lines", [strFilteredQueryResultsAr count]);
			
			NSData *daFixedQueryResult = [strQueryResult dataUsingEncoding:NSUTF8StringEncoding];
			// THIS CRASHES THE PARSER?????   [strQueryResult release];
			[strFilteredQueryResultsAr release];
			BOOL success = NO;
			NSXMLParser *parser = [[NSXMLParser alloc] initWithData:daFixedQueryResult];
			// ANLY Says not ours to release!!!   [daFixedQueryResult release];
			[parser setDelegate:self];
			[parser setShouldProcessNamespaces:NO];
			[parser setShouldReportNamespacePrefixes:NO];
			[parser setShouldResolveExternalEntities:NO];
			
			// follwing 'success' is never used!
			success = [parser parse];
			NSError *parseError = [parser parserError];
			if (parseError) {
				NSLog(@"parse error = %@", parseError);
				[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
				// ANLY SAYS not ours to release!!! [parseError release];
			}
			// THIS CRASHES THE PARSER?????  [parser release];
			[pool drain];
		}
	}
	return bWasParseSuccessful;
}

#pragma mark -
#pragma mark XML Parser Delegates

- (void)parserDidEndDocument:(NSXMLParser *)parser {
	
	// tell the main app that parsing has completed
	[(id)[self delegate] performSelectorOnMainThread:@selector(parserFinished)
										  withObject:nil
									   waitUntilDone:NO];
	
	NSLog(@"PARSER parserDidEndDocument");
	// THIS CRASHES THE PARSER?????  [self autorelease];
}


/*
 Sample entry
 
 <table>
  <tr>
 
 ** Col-1  CALLSIGN
   <td> <a href="find.cgi?KC0LNO">KC0LNO</a> </td>

 ** Col-2  URL to Message traffic if avail.  otherwise  "<td align=center>.</td>"
   <td ALIGN="center"><a href="msg.cgi?KC0LNO">**</a></td>

 ** Col-3  URL to Weather page if avail.  otherwise  "<td align=center>.</td>"
   <td ALIGN="center"><a href="wxpage.cgi?KC0LNO">**</a></td>

 ** Col-4  Lattitude
   <td> 39.08383</td>

 ** Col-5  Longitude
   <td> -104.87117</td>

 ** Col-6  Distance from me (in miles)
   <td>3.4 </td>
 
 ** Col-7  DD:HH:MM:SS of last report
   <td> 00:00:00:21 </td>
  </tr>
 </table>

*/
NSString *kCallSignCol			= @"Callsign";
NSString *kMsgURLCol			= @"MsgURL";
NSString *kWxURLCol				= @"WxURL";
NSString *kLatitudeCol			= @"Lat";
NSString *kLongitudeCol			= @"Long";
NSString *kDistanceCol			= @"Distance";
NSString *kLastReportCol		= @"LastReport";
NSString *kUnknownCol           = @"???";	// re didn't recognize the column number

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
    attributes:(NSDictionary *)attributeDict {
	if(nil != qName) {
		elementName = qName; // swap for the qName if we have a name space
	}
	//NSLog(@"HTML parser at element=%@", elementName);
	
	if([elementName isEqualToString:@"table"]) {
		NSLog(@"HTML parser at element=%@", elementName);
		// at the beginning of (fingers-crossed) our only table
		m_bIsProcessingTable = true;	// now things we find are valid!
		
	} else if ([elementName isEqualToString:@"tr"]) {
		NSLog(@"HTML parser at element=%@", elementName);
		// at the beginning of our new row (a new Amateur APRS station)
		m_nColumnNbr = 0;	// reset to before first column
		self.currentStation = [[[APRSstation alloc] init] autorelease];
		
	} else if([elementName isEqualToString:@"td"]) {
		// have a new column in our current station def'n
		m_nColumnNbr++;	// pre-increment so our columns start at one!
		switch (m_nColumnNbr) {
			case 1:
				m_strColumnName = kCallSignCol;
				break;
			case 2:
				m_strColumnName = kMsgURLCol;
				break;
			case 3:
				m_strColumnName = kWxURLCol;
				break;
			case 4:
				m_strColumnName = kLatitudeCol;
				break;
			case 5:
				m_strColumnName = kLongitudeCol;
				break;
			case 6:
				m_strColumnName = kDistanceCol;
				break;
			case 7:
				m_strColumnName = kLastReportCol;
				break;
			default:
				m_strColumnName = kUnknownCol;
				break;
		}
		self.propertyValue = [NSMutableString string];
	} else if([elementName isEqualToString:@"a"]) {
		NSLog(@"HTML parser at element=%@", elementName);
		// if we are processing station data then we need this link...
		if(m_bIsProcessingTable)
		{
			switch (m_nColumnNbr) {
				case 2:
					{
						NSString *link = [attributeDict valueForKey:@"href"];
						self.currentStation.msgURL = 
							[NSString stringWithFormat:@"http://www.findU.com/cgi-bin/%@", link];
					}
					break;
				case 3:
					{
						NSString *link = [attributeDict valueForKey:@"href"];
						self.currentStation.wxURL = 
							[NSString stringWithFormat:@"http://www.findU.com/cgi-bin/%@", link];
					}
					break;
				default:
					break;
			}
		}
	} else {
		NSLog(@" - element not used %@",elementName);
		self.propertyValue = nil;
	}
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
	if(self.propertyValue != nil) {
		[self.propertyValue appendString:string];
	}
}

-(NSString *)trim:(NSString *)strNeedingTrim
{
	NSString *strTrimmedString = [strNeedingTrim stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	return strTrimmedString;
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {     
	if (qName) {
		elementName = qName; // switch for the qName
	}
	
	//NSLog(@"HTML parser ended element=%@", elementName);
	
	if ([elementName isEqualToString:@"td"]) {
		if ([m_strColumnName isEqualToString:kCallSignCol]) {
			self.currentStation.callSign = [self trim:self.propertyValue];
			
		} else if ([m_strColumnName isEqualToString:kLatitudeCol]) {
			NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
			if(m_nLatitude == nil)
			{
				m_nLatitude = [[NSNumber alloc] init];
			}
			m_nLatitude = [formatter numberFromString:[self trim:self.propertyValue]];
			[formatter release];
			
		} else if ([m_strColumnName isEqualToString:kLongitudeCol]) {
			NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
			NSNumber *nLongitude = [formatter numberFromString:[self trim:self.propertyValue]];
			[formatter release];
			CLLocation *location = [[CLLocation alloc] initWithLatitude:m_nLatitude.floatValue
															  longitude:nLongitude.floatValue];
			// INCORRECT DECR [nLongitude release];
			self.currentStation.position = location;
			[location release];
			
		} else if ([m_strColumnName isEqualToString:kDistanceCol]) {			
			NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
			self.currentStation.distanceInMiles = [formatter numberFromString:[self trim:self.propertyValue]];
			[formatter release];
			
		} else if ([m_strColumnName isEqualToString:kLastReportCol]) {
			//NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
			//[formatter setDateFormat:@"dd:HH:mm:ss"];
			self.currentStation.lastReport = m_dtTimeOfDataFetch;  // UNDONE this need to be adjusted by timeSince...
			self.currentStation.timeSinceLastReport = [self trim:self.propertyValue];;
			//[formatter release];
			
		}
	} else if([elementName isEqualToString:@"tr"]) {
		NSLog(@" -- parser ended element=%@", elementName);
		[(id)[self delegate] performSelectorOnMainThread:@selector(addAPRSstation:)
											  withObject:self.currentStation
										   waitUntilDone:NO];
	}
}

- (void)parser:(NSXMLParser *)parser parseErrorOccurred:(NSError *)parseError {
	if(parseError.code != NSXMLParserDelegateAbortedParseError) {
		NSLog(@"parser error=%d %@, userInfo %@", parseError.code, parseError, [parseError userInfo]);
	}
}


@end
