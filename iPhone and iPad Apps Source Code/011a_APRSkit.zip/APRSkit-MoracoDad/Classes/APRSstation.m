//
//  APRSstation.m - IMPLEMENTATION
//  MapAPRS-MoracoDad
//
//  This class represents the details parsed from our
//  APRS traffic report for a single APRS equipped 
//  amateur radio station
//
//  Created by Stephen on 10/17/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import "APRSstation.h"


@implementation APRSstation

@synthesize callSign = m_strCallsign;
@synthesize distanceInMiles = m_nDistanceInMiles;
@synthesize lastReport = m_dtLastReport;
@synthesize msgURL = m_strMsgURL;
@synthesize wxURL = m_strWxURL;
@synthesize position = m_locPosition;
@synthesize timeSinceLastReport = m_strTimeSinceLastReport;


- (void) dealloc {
	NSLog(@"APRSstation:dealloc (%@) - ENTRY",self.callSign);
	[self.callSign release];
	[self.distanceInMiles release];
	[self.lastReport release];
	[self.msgURL release];
	[self.wxURL release];
	[self.position release];
	[self.timeSinceLastReport release];
	[super dealloc];
}

@end
