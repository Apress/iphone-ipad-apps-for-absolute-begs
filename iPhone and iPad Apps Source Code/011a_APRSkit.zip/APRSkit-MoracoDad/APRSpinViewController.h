//
//  APRSpinViewController.h
//  APRSkit-MoracoDad
//
//  Created by Stephen on 10/24/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "PinAnnotation.h"
#import "APRSwebViewController.h"

@interface APRSpinViewController : UIViewController <CLLocationManagerDelegate, MKMapViewDelegate, UIActionSheetDelegate> {
	MKMapView *m_mvMap;
	UIBarButtonItem *m_btnSendReport;
	UISegmentedControl *m_ctlMapTypeChooser;
	CLLocationManager *m_lmLocationManager;
	MKReverseGeocoder *m_rgReverseGeocoder;
	PinAnnotation *m_paNewLocation;
	APRSwebViewController *m_wvBrowserController;
}

@property (nonatomic, retain) IBOutlet MKMapView *mapView;
@property (nonatomic, retain) IBOutlet UISegmentedControl *ctlMapTypeChooser;
@property (nonatomic, retain) CLLocationManager *locationManager;
@property (nonatomic, retain) MKReverseGeocoder *reverseGeocoder;
@property (nonatomic, retain) IBOutlet APRSwebViewController *webBrowserController;

-(IBAction)sendPostion:(id)sender;
-(IBAction)selectMapMode:(id)sender;

@end
