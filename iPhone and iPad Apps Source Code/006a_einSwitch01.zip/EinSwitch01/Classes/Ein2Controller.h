//
//  Ein2Controller.h
//  EinSwitch01
//
//  Created by Rory Lewis on 11/1/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface Ein2Controller : UIViewController {

}

@end
