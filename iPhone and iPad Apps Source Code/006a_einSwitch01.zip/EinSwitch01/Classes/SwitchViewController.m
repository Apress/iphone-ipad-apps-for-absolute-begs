//
//  SwitchViewController.m
//  EinSwitch01
//
//  Created by Rory Lewis on 11/1/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "SwitchViewController.h"
#import "Ein1Controller.h"
#import "Ein2Controller.h"

@implementation SwitchViewController
@synthesize ein1Controller;
@synthesize ein2Controller;


- (void)viewDidLoad
{
	Ein1Controller *ein1Controller = [[Ein1Controller alloc] 
									  initWithNibName:@"Einstein1View" bundle:nil];
	self.ein1Controller = ein1Controller;
	[self.view insertSubview:ein1Controller.view atIndex:0];
	[ein1Controller release];
}


- (IBAction)switchViews:(id)sender
{
  	// Lazy load - we load the Einstein2View nib the first time the button is pressed
	if (self.ein2Controller == nil)
	{
		Ein2Controller *ein2Controller = 
		[[Ein2Controller alloc] initWithNibName:@"Einstein2View" 
										 bundle:nil];
		self.ein2Controller = ein2Controller;
		[ein2Controller release];
	}
	
	if (self.ein1Controller.view.superview == nil)
		//This is with no animation
	{
		[ein2Controller.view removeFromSuperview];
		[self.view insertSubview:ein1Controller.view atIndex:0];
	}
	else
	{
		[ein1Controller.view removeFromSuperview];
		[self.view insertSubview:ein2Controller.view atIndex:0];
	}
}
// Initialization code
- (id)initWithNibName:(NSString *)nibNameOrNil
			   bundle:(NSBundle *)nibBundleOrNil {
	if (self = [super initWithNibName:nibNameOrNil
							   bundle:nibBundleOrNil]) {
		
	}
	return self;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
	if (self.ein1Controller.view.superview == nil) 
		self.ein1Controller = nil;
	else
		self.ein1Controller = nil;
}

- (void)dealloc {
	[ein2Controller release];
	[ein1Controller release];
	[super dealloc];
}
@end
