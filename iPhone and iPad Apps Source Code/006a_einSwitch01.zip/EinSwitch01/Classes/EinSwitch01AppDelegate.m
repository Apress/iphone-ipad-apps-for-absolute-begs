//
//  EinSwitch01AppDelegate.m
//  EinSwitch01
//
//  Created by Rory Lewis on 11/1/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "EinSwitch01AppDelegate.h"
#import "SwitchViewController.h"

@implementation EinSwitch01AppDelegate

@synthesize window, switchViewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    

    // Override point for customization after application launch
    [window addSubview:switchViewController.view];
	[window makeKeyAndVisible];
}


- (void)dealloc {
    [window release];
	[switchViewController release];
    [super dealloc];
}


@end
