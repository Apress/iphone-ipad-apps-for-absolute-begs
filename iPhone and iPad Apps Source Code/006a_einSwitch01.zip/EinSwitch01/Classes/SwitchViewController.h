//
//  SwitchViewController.h
//  EinSwitch01
//
//  Created by Rory Lewis on 11/1/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class Ein1Controller;
@class Ein2Controller;

@interface SwitchViewController : UIViewController {
	Ein2Controller *ein2Controller;
	Ein1Controller *ein1Controller;
}

@property (retain, nonatomic) Ein2Controller *ein2Controller;
@property (retain, nonatomic) Ein1Controller *ein1Controller;

-(IBAction)switchViews:(id)sender;

@end
