//
//  helloWorld_004AppDelegate.h
//  helloWorld_004
//
//  Created by Rory Lewis on 8/31/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class helloWorld_004ViewController;

@interface helloWorld_004AppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    helloWorld_004ViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet helloWorld_004ViewController *viewController;

@end

