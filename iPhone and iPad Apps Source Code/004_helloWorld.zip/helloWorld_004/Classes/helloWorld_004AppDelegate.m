//
//  helloWorld_004AppDelegate.m
//  helloWorld_004
//
//  Created by Rory Lewis on 8/31/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "helloWorld_004AppDelegate.h"
#import "helloWorld_004ViewController.h"

@implementation helloWorld_004AppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
