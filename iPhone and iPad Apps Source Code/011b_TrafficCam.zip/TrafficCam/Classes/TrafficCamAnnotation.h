//
//  TrafficCamAnnotation.h
//  TrafficCam
//
//  Created by Steve on 10/25/09.
//  Copyright 2009 Home. All rights reserved.
//

//#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

@class TrafficCam;

@interface TrafficCamAnnotation : NSObject <MKAnnotation> {
	CLLocationCoordinate2D Coordinate;
	NSString *Title;
	NSString *Subtitle;
	TrafficCam *Cam;
}

@property(nonatomic, assign) CLLocationCoordinate2D coordinate;
@property(nonatomic, retain) NSString *title;
@property(nonatomic, retain) NSString *subtitle;
@property(nonatomic, retain) TrafficCam *cam;

+ (id)annotationWithCam:(TrafficCam *)Cam;
- (id)initWithCam:(TrafficCam *)Cam;


@end
