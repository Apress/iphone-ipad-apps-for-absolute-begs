//
//  TrafficCamAppDelegate.m
//  TrafficCam
//
//  Created by Steve on 10/25/09.
//  Copyright Home 2009. All rights reserved.
//

#import "TrafficCameraAppDelegate.h"
#import "TrafficCameraViewController.h"

@implementation TrafficCameraAppDelegate

@synthesize window;
@synthesize viewController, mMapTypeSelected;
@synthesize distanceInMiles = m_strDistanceInMiles;

#pragma mark -
#pragma mark Keys Used for Application Settings Access

NSString *kDistanceInMilesKey	= @"TrafficCam-DistanceInMiles";
NSString *strEmptyString		= @"";


#pragma mark -
#pragma mark Application lifecycle

- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
	//NSLog(@"App Launched"); 
	NSLog(@"MapAPRS_MoracoDadAppDelegate:applicationDidFinishLaunching - ENTRY");

	// preload our applcation defaults
	NSUserDefaults *upSettings = [NSUserDefaults standardUserDefaults];	
	NSString *strDefaultDistanceInMiles = [upSettings stringForKey:kDistanceInMilesKey];
	if(strDefaultDistanceInMiles == nil)
	{
		strDefaultDistanceInMiles = @"30";
	}
	self.distanceInMiles = strDefaultDistanceInMiles;
	//[strDefaultSitePassword release];
	// INCORRECT DECR [upSettings release];
}

-(void)SavePeferences
{
	NSLog(@"APRSkit_MoracoDadAppDelegate:SavePreferences - ENTRY");
	// Save data if appropriate
	NSUserDefaults *upSettings = [NSUserDefaults standardUserDefaults];
	[upSettings setObject:self.distanceInMiles forKey:kDistanceInMilesKey];
	[upSettings synchronize];
	// INCORRECT DECR [upSettings release];
}

- (void)applicationWillResignActive:(UIApplication *)application
{
	// Save data ...
	NSLog(@"APRSkit_MoracoDadAppDelegate:applicationWillResignActive - ENTRY");
	// Save data as we exit
	[self SavePeferences];
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
	// Save data ...
	NSLog(@"APRSkit_MoracoDadAppDelegate:applicationDidBecomeActive - ENTRY");
	// UNDONE are pref's still loaded???? maybe load here?
}


- (void)applicationWillTerminate:(UIApplication *)application {
	// Save data if appropriate
	NSLog(@"APRSkit_MoracoDadAppDelegate:applicationWillTerminate - ENTRY");
	// Save data as we exit
	[self SavePeferences];
}




- (void)dealloc {
    [viewController release];
	[self.distanceInMiles release];
    [window release];
    [super dealloc];
}

@end

