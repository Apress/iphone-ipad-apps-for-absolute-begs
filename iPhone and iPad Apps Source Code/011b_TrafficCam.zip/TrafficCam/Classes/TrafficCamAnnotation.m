//
//  TrafficCamAnnotation.m
//  TrafficCam
//
//  Created by Steve on 10/25/09.
//  Copyright 2009 Home. All rights reserved.
//

#import "TrafficCamAnnotation.h"
#import "TrafficCam.h"

@implementation TrafficCamAnnotation

@synthesize coordinate = Coordinate;
@synthesize title = Title;
@synthesize subtitle = Subtitle;
@synthesize cam = Cam;

+ (id)annotationWithCam:(TrafficCam *)cam
{
	////NSLog(@"BeforeREturn");
	return [[[[self class] alloc] initWithCam:cam] autorelease];
}

- (id)initWithCam:(TrafficCam *)cam
{
	self = [super init];
	if(nil != self) {
		self.title = [NSString stringWithFormat:@"%@", cam.CamDescription];
		self.subtitle = [NSString stringWithFormat:@"%@", cam.CamOrientation];
		self.coordinate = cam.CamPosition.coordinate;
		self.cam = cam;
		//NSLog(@"TrafficCamAnnotation:initWithCam=%@",self.title);
	}
	return self;
}

- (void) dealloc {
	//NSLog(@"TrafficCamAnnotation:dealloc=%@",self.title);
	[self.title release];
	[self.subtitle release];
	[self.cam release];
	[super dealloc];
}


@end
