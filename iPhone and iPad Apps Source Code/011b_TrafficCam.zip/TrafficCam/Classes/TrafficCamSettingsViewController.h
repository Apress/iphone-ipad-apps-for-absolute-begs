//
//  TrafficCamSettingsViewController.h
//  TrafficCam
//
//  Created by Steve on 12/6/09.
//  Copyright 2009 Home. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TrafficCameraViewController;

@interface TrafficCamSettingsViewController : UIViewController {
		TrafficCameraViewController *vcDelegate;
		UISlider *slider;
		UILabel *sliderLabel;
		int mMapStyleIdx;
		UISegmentedControl *mapTypeSelector;
}


@property (nonatomic, retain) TrafficCameraViewController *vcDelegate;
@property (nonatomic, retain) IBOutlet UISlider *slider;
@property (nonatomic, retain) IBOutlet UILabel *sliderLabel;
@property (nonatomic, assign) int mMapStyleIdx;
@property (nonatomic, retain) IBOutlet UISegmentedControl *mapTypeSelector;

-(IBAction)DoneButtonPressed:(id)sendr;
-(IBAction)CancelButtonPressed:(id)sendr;
-(IBAction)selectMapMode:(id)sender;
-(IBAction)sliderChanged:(id)sender;

@end
