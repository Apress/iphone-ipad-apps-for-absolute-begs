//
//  TrafficCamParser.m
//  TrafficCam
//
//  Created by Steve on 10/25/09.
//  Copyright 2009 Home. All rights reserved.
//


#import "TrafficCam.h"
#import "TrafficCamParser.h"
#import "TrafficCamAnnotation.h"

@implementation TrafficCamParser

@synthesize currentCam = cCurrentCam;
@synthesize propertyValue = PropertyValue;
@synthesize delegate = tcpDelegate;
@synthesize retrieverQueue = RetrieverQueue;

+ (id)newTrafficCamParser
{
	// POTENTIAL LEAK ignored!! is class factory method!
	return [[[self class] alloc] init];
}

- (NSOperationQueue *)retrieverQueue {
	if(nil == RetrieverQueue) {
		RetrieverQueue = [[NSOperationQueue alloc] init];
		RetrieverQueue.maxConcurrentOperationCount = 1;
	}
	return RetrieverQueue;
}

- (void)getCamData
{
	//NSLog(@"TrafficCamParser:getCamData - ENTRY  ***\n\n");
	SEL method = @selector(parseForData);
	NSInvocationOperation *op = [[NSInvocationOperation alloc] initWithTarget:self 
																	 selector:method 
																	   object:nil];
	[self.retrieverQueue addOperation:op];
	[op release];
}

#pragma mark -
#pragma mark Parser Toplevel Routines

static NSString *strURL = @"http://www.mhartman-wx.com/wcn/wcn_db.txt";

// this method is fired by the operation created in
// getEarthquakeData so its on an alternate thread
- (BOOL)parseForData {
	BOOL bWasParseSuccessful = true;
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];

	// show querying network for data...
	[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
	NSURL *url = [NSURL URLWithString:strURL];
	// INCORRECT DECR!!		[strFullQueryURL release];
	//
	// adapter to filter out bad meta tags in <HEAD></HEAD> sectiion
	//  along with all other findings...
	//
	
	// retrieve the text to process
	NSError *anError = nil;
	NSString *strQueryResults = [NSString stringWithContentsOfURL:url encoding:NSWindowsCP1250StringEncoding error:&anError];

	if(strQueryResults == nil)
	{
		//NSLog(@"ERROR reading URL: message=[%@] url=[%@]", [anError localizedDescription], strURL);
	}
	else
	{
		//NSLog(@"SUCCESS, read data from server!");
	}
	// INCORRECT DECR!!		[url release];
	
	// set the date time of this data-read
	TimeOfDataFetch = [NSDate date];	// time now...
	
	/*
	 Rules - 
	 Replace ^ with </field><field>
	 replace <br>'s with blank space
	 replace "<font size=\"-1\">(" and ")<br>" with </field><field>
	 start and end with <CAM><field> and </field></CAM>
	 remove </font> tags
	 remove non-breaking spaces
	 fix other misc stuff
	*/
	 
	NSString *strNoParaQueryResults = [strQueryResults stringByReplacingOccurrencesOfString:@"<font size=\"-1\">(" withString:@"</field><field>"];
	strNoParaQueryResults = [strNoParaQueryResults stringByReplacingOccurrencesOfString:@")<br>" withString:@"</field><field>"];
	strNoParaQueryResults = [strNoParaQueryResults stringByReplacingOccurrencesOfString:@"</font>" withString:@""];
	strNoParaQueryResults = [strNoParaQueryResults stringByReplacingOccurrencesOfString:@"&nbsp;" withString:@""];
	strNoParaQueryResults = [strNoParaQueryResults stringByReplacingOccurrencesOfString:@"></a>" withString:@"></img></a>"];
	
	strNoParaQueryResults = [strNoParaQueryResults stringByReplacingOccurrencesOfString:@"width=150" withString:@"width=\"150\""];
	strNoParaQueryResults = [strNoParaQueryResults stringByReplacingOccurrencesOfString:@"height=100" withString:@"height=\"100\""];
	strNoParaQueryResults = [strNoParaQueryResults stringByReplacingOccurrencesOfString:@"width=100" withString:@"width=\"100\""];
	strNoParaQueryResults = [strNoParaQueryResults stringByReplacingOccurrencesOfString:@"height=150" withString:@"height=\"150\""];
	strNoParaQueryResults = [strNoParaQueryResults stringByReplacingOccurrencesOfString:@"border=0" withString:@"border=\"0\""];
	strNoParaQueryResults = [strNoParaQueryResults stringByReplacingOccurrencesOfString:@"\"\"" withString:@"\""];
	strNoParaQueryResults = [strNoParaQueryResults stringByReplacingOccurrencesOfString:@".jpg " withString:@".jpg\" "];
	//strNoParaQueryResults = [strNoParaQueryResults stringByReplacingOccurrencesOfString:@":</b>" withString:@"</b>"];
	//individual errors
	strNoParaQueryResults = [strNoParaQueryResults stringByReplacingOccurrencesOfString:@"&" withString:@"and"];
	strNoParaQueryResults = [strNoParaQueryResults stringByReplacingOccurrencesOfString:@"<font size=\"-1\">" withString:@""];
	strNoParaQueryResults = [strNoParaQueryResults stringByReplacingOccurrencesOfString:@"</b<" withString:@"</b><"];
	
	NSArray *strQueryResultAr = [strNoParaQueryResults componentsSeparatedByString:@"\n"];
	// INCORRECT DECR!!  [strNoParaQueryResults release];
	// INCORRECT DECR!! [strQueryResults release];
	
	//NSLog(@"FILTER: data in hand, now filtering...%d lines received",[strQueryResultAr count]);
	NSMutableArray *strFilteredQueryResultsAr = [[NSMutableArray alloc] init];
	NSEnumerator *eCurrentObject = [strQueryResultAr objectEnumerator];
	NSString *strCurrLine;
	int nbrLinesWritten = 0;
	lineNbr = 0;
	//int count2 = 0;
	do
	{
		strCurrLine = (NSString *)[eCurrentObject nextObject];
		
		//The following skips x/2 of cameras.
		//if (count2 < 3600) {
		//	count2++;
		//	continue;
		//	//Skip first 1000 cameras.
		//}
		if([strCurrLine length] == 0)
		{
			//do nothing to empty lines
			continue;
		}
		
		NSRange rngSearchResult = [strCurrLine rangeOfString:@"Requires" options:NSCaseInsensitiveSearch];
		if (rngSearchResult.location != NSNotFound){
			//don't include lines that require video. Especially windows video. Heh.
			continue;
		}
		
		rngSearchResult = [strCurrLine rangeOfString:@"Video" options:NSCaseInsensitiveSearch];
		if (rngSearchResult.location != NSNotFound){
			//don't include lines that require video. Especially windows video. Heh.
			continue;
		}
		rngSearchResult = [strCurrLine rangeOfString:@"Live-Cam" options:NSCaseInsensitiveSearch];
		if (rngSearchResult.location != NSNotFound){
			//don't include lines that require video. Especially windows video. Heh.
			continue;
		}
		strCurrLine = [NSString stringWithFormat:@"<CAM><field>%@</field></CAM>", strCurrLine];
		////NSLog(@"Added Edges - Current String:\n %@", strCurrLine);
		strCurrLine = [strCurrLine stringByReplacingOccurrencesOfString:@"^" withString:@"</field><field>"];
		////NSLog(@"Replaced ^ - Current String:\n %@", strCurrLine);
		strCurrLine = [strCurrLine stringByReplacingOccurrencesOfString:@"<br>" withString:@""];
		strCurrLine = [strCurrLine stringByReplacingOccurrencesOfString:@"<font size=\"-\">" withString:@""];
		//strCurrLine = [strCurrLine stringByReplacingOccurrencesOfString:@")" withString:@"</field><field>"];
		//strCurrLine = [strCurrLine stringByReplacingOccurrencesOfString:@"(" withString:@"</field><field>"];
		
		strCurrLine = [strCurrLine stringByReplacingOccurrencesOfString:@".</a>" withString:@"."];
		strCurrLine = [strCurrLine stringByReplacingOccurrencesOfString:@"t</a><a" withString:@"t<a"];
		strCurrLine = [strCurrLine stringByReplacingOccurrencesOfString:@">Northwest<a" withString:@">Northwest</a><a"];
		strCurrLine = [strCurrLine stringByReplacingOccurrencesOfString:@"\"></field><field>gov" withString:@"\"></img></a></field><field>gov"];
		strCurrLine = [strCurrLine stringByReplacingOccurrencesOfString:@">West<a" withString:@">West</a><a"];
		strCurrLine = [strCurrLine stringByReplacingOccurrencesOfString:@">South Minot<a" withString:@">South Minot</a><a"];
		strCurrLine = [strCurrLine stringByReplacingOccurrencesOfString:@">East<a" withString:@">East</a><a"];
		strCurrLine = [strCurrLine stringByReplacingOccurrencesOfString:@">Northeast<a" withString:@">Northeast</a><a"];
		strCurrLine = [strCurrLine stringByReplacingOccurrencesOfString:@">b>" withString:@"><b>"];
		strCurrLine = [strCurrLine stringByReplacingOccurrencesOfString:@">Southwest<a" withString:@">Southwest</a><a"];
		strCurrLine = [strCurrLine stringByReplacingOccurrencesOfString:@">East-Southeast<a" withString:@">East-Southeast</a><a"];
		strCurrLine = [strCurrLine stringByReplacingOccurrencesOfString:@">Southeast<a" withString:@">Southeast</a><a"];
		strCurrLine = [strCurrLine stringByReplacingOccurrencesOfString:@">Southeast<a" withString:@">Southeast</a><a"];
		
		//NSLog(@"Line (%d) - Current String:\n %@", lineNbr, strCurrLine);
		[strFilteredQueryResultsAr addObject:strCurrLine];
		lineNbr++;
		nbrLinesWritten++;
				
	} while (strCurrLine != nil); //nbrLinesWritten < 1000 && 
	
	// THIS CRASHES THE PARSER?????   [strQueryResultAr release];
	
	NSString *strQueryResult = [strFilteredQueryResultsAr componentsJoinedByString:@"\n"];
	strQueryResult = [NSString stringWithFormat:@"<cameras>\n%@\n</cameras>\n", strQueryResult];
	////NSLog(@"strQueryResult:\n [%@]", strQueryResult);
	//NSLog(@"FILTER: filter complete, %d output lines", [strFilteredQueryResultsAr count]);
	
	NSData *daFixedQueryResult = [strQueryResult dataUsingEncoding:NSUTF8StringEncoding];
	[strFilteredQueryResultsAr release];
	// THIS CRASHES THE PARSER?????   [strQueryResult release];
	
	BOOL success = NO;
	NSXMLParser *parser = [[NSXMLParser alloc] initWithData:daFixedQueryResult];
	//[daFixedQueryResult release];
	[parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
	[parser setShouldReportNamespacePrefixes:NO];
	[parser setShouldResolveExternalEntities:NO];
	
	// follwing 'success' is never used!
	success = [parser parse];
	NSError *parseError = [parser parserError];
	if (parseError) {
		//NSLog(@"parse error = %@", parseError);
		[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
		[parseError release];
	}
	// THIS CRASHES THE PARSER?????  [parser release];
	[pool drain];
	return bWasParseSuccessful;
}

- (void)parserDidEndDocument:(NSXMLParser *)parser {
	[(id)[self delegate] performSelectorOnMainThread:@selector(parserFinished)
										  withObject:nil
									   waitUntilDone:NO];
	
	//NSLog(@"PARSER parserDidEndDocument");
	// show the our querying of network is complete
	[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
	// THIS CRASHES THE PARSER?????  [self autorelease];
}

- (void) dealloc {
	//NSLog(@"TrafficCamParser:dealloc - ENTRY");
	
	[self.currentCam release];
	[self.propertyValue release];
	[self.delegate release];
	[self.retrieverQueue release];
	[strElementName release];
	[nLatitude release];
	[TimeOfDataFetch release];
	
	[super dealloc];
}


#pragma mark -
#pragma mark Actual Parsing Routines

/*
 Sample entry
 **all of the following is on one line in the source

 <CAM>
 
 ** ele-1
 <field>50.628435</field>
 
 ** ele-2
 <field>-111.966813</field>
 
 ** ele-3
 <field><b>AB-MOT</b></field>
 
 ** ele-4
 <field>(Hwy 1 near Brooks)</field>
 
 ** ele-5 <---ignored
 <field>View is to the northwest.  <a href="http://www.ama.ab.ca/road_report/camera/1-18b.htm" target="_blank">Wx Data</a></field>
 
 ** ele-6
 <field><a href="http://www.ama.ab.ca/road_report/camera/camera_images/1-18b_1.jpg" target="_blank"><img src="http://www.ama.ab.ca/road_report/camera/camera_images/1-18b_1.jpg" width=150 height=100 border=0></img></a></field>
 
 ** ele-7 <---ignored
 <field>dot</field>
 
 </CAM>
 
 */
NSString *kLatitudeCol			= @"Lat";
NSString *kLongitudeCol			= @"Long";
NSString *kCamOrientation		= @"Provider";
NSString *kCamDescription		= @"Location";
// ele-5
NSString *kCamUrl				= @"CamURL";
// ele-7
NSString *kUnknownCol           = @"???";	// re didn't recognize the column number

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
    attributes:(NSDictionary *)attributeDict {
	if(nil != qName) {
		elementName = qName; // swap for the qName if we have a name space
	}
	////NSLog(@"HTML parser at element=%@", elementName);
	if([elementName isEqualToString:@"cameras"]) {
		//NSLog(@"HTML parser at element=%@", elementName);
		lineNbr = -1;
	} else if([elementName isEqualToString:@"CAM"]) {
		lineNbr++;
		//NSLog(@"HTML parser at element=%@", elementName);
		// at the beginning of (fingers-crossed) our only table
		// now things we find are valid!
		nElementNbr = 0;	// reset to before first column
		self.currentCam = [[[TrafficCam alloc] init] autorelease];
		//NSLog(@"currentCam allocated!");
		
	} else if([elementName isEqualToString:@"field"]) {
		// have a new element in our current Cam def'n
		nElementNbr++;	// pre-increment so our columns start at one!
		//subElementNbr = 0; //reset before each subelement group
		//NSLog(@"HTML parser at element=%@ #%d", elementName, nElementNbr);		
		switch (nElementNbr) {
			case 1:
				strElementName = kLatitudeCol;
				break;
			case 2:
				strElementName = kLongitudeCol;
				break;
			case 3:
				strElementName = kCamOrientation;
				break;
			case 4:
				//location
				strElementName = kCamDescription;
				break;
			case 5:
				//url in an <a> tag
				strElementName = kCamUrl;
				break;
			case 6:
				//feild 6 is the camera type (i.e. weather, DOT, School, Ski, etc.)
				//break
				
			default:
				strElementName = kUnknownCol;
				break;
		}
		if (strElementName != kUnknownCol) {
			self.propertyValue = [NSMutableString string];
		}
		
	} else if([elementName isEqualToString:@"a"]) {
		//NSLog(@"HTML parser at element=%@", elementName);
		// if we are processing Cam data then we need this link...
		//subElementNbr++; //pre-increment
		 //switch (subElementNbr) {
		 //case 2:
		 //{
		 //self.propertyValue = nil;
		//nil because it's not being read.
		//}
		//		break;
		//	default:
		//		break;
		//}
	} else if([elementName isEqualToString:@"b"]) {
			//NSLog(@"HTML parser at element=%@", elementName);
		//not doing anything because this value is gathered upon end of tag.
	} else if([elementName isEqualToString:@"img"]) {
		//NSLog(@"HTML parser at element=%@", elementName);
		
		NSString *link = [attributeDict valueForKey:@"src"];
		self.currentCam.CamUrl = [NSString stringWithFormat:@"%@", link];
		//NSLog(@"Got URL: [%@]", link);
		
	} else {
		//NSLog(@" - element not used %@",elementName);
		self.propertyValue = nil;
	}
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
	if(self.propertyValue != nil) {
		[self.propertyValue appendString:string];
	}
}

-(NSString *)trim:(NSString *)strNeedingTrim
{
	NSString *strTrimmedString = [strNeedingTrim stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	return strTrimmedString;
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {     
	if (qName) {
		elementName = qName; // switch for the qName
	}
	
	////NSLog(@"HTML parser ended element=%@", elementName);
	
	if ([elementName isEqualToString:@"field"]) {
		//NSLog(@"Parser ended element = %@ #%d", elementName, nElementNbr);
		if ([strElementName isEqualToString:kCamDescription]) {
			self.currentCam.CamDescription = [self trim:self.propertyValue];
			
		} else if ([strElementName isEqualToString:kLatitudeCol]) {
			NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
			if(nLatitude == nil)
			{
				nLatitude = [[NSNumber alloc] init];
			}
			nLatitude = [formatter numberFromString:[self trim:self.propertyValue]];
			//NSLog(@"Got Lat = %@", self.propertyValue);
			[formatter release];
			
		} else if ([strElementName isEqualToString:kLongitudeCol]) {
			NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
			NSNumber *nLongitude = [formatter numberFromString:[self trim:self.propertyValue]];
			[formatter release];
			//NSLog(@"Got Long = %@", self.propertyValue);
			CLLocation *location = [[CLLocation alloc] initWithLatitude:nLatitude.floatValue
															  longitude:nLongitude.floatValue];
			// INCORRECT DECR [nLongitude release];
			self.currentCam.CamPosition = location;
			[location release];
			
		}
		
	} else if([elementName isEqualToString:@"b"]) {
		if ([strElementName isEqualToString:kCamOrientation]) 
		{
			self.currentCam.CamOrientation = self.propertyValue;
			//NSLog(@"Got Orientation and ended element=%@", elementName);	
		}
	} else if([elementName isEqualToString:@"img"]) {
		//NSLog(@"HTML parser ended element=%@", elementName);
		//  ignore them' image tags.
		
		
	} else if([elementName isEqualToString:@"a"]) {
		//NSLog(@"HTML parser ended element=%@, Line Number = %d", elementName, lineNbr);
		//  ignore them' image tags.
		
		
	}else if([elementName isEqualToString:@"CAM"]) {
		//NSLog(@" -- parser ended element=%@", elementName);
		[(id)[self delegate] performSelectorOnMainThread:@selector(addTrafficCam:)
											  withObject:self.currentCam
										   waitUntilDone:NO];
		////NSLog(@"Camera sent off to battle.");
	}else if([elementName isEqualToString:@"cameras"]) {
		//NSLog(@"HTML parser ended element=%@", elementName);
	}
}

- (void)parser:(NSXMLParser *)parser parseErrorOccurred:(NSError *)parseError {
	if(parseError.code != NSXMLParserDelegateAbortedParseError) {
		//NSLog(@"parser error=%d %@, userInfo %@, Line Number %d, Value = %@", parseError.code, parseError, [parseError userInfo], lineNbr, self.propertyValue);
	}
}


@end

