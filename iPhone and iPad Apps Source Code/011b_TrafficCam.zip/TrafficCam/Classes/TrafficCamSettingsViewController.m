//
//  TrafficCamSettingsViewController.m
//  TrafficCam
//
//  Created by Steve on 12/6/09.
//  Copyright 2009 Home. All rights reserved.
//

#import "TrafficCamSettingsViewController.h"
#import "TrafficCameraViewController.h"
#import <Foundation/Foundation.h>
#import "TrafficCameraAppDelegate.h"

@implementation TrafficCamSettingsViewController

@synthesize vcDelegate, slider, sliderLabel, mMapStyleIdx, mapTypeSelector;

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	[[UIApplication sharedApplication] setStatusBarStyle: UIStatusBarStyleBlackOpaque];
    [super viewDidLoad];
	slider.maximumValue = 500;
	slider.minimumValue = 2;
	TrafficCameraAppDelegate *appDelegate = (TrafficCameraAppDelegate *)[[UIApplication sharedApplication] delegate];
	slider.value = [appDelegate.distanceInMiles intValue];
	sliderLabel.text = [NSString stringWithFormat:@"%@ Miles",[[NSNumber numberWithInt:slider.value] stringValue]];
	slider.continuous = YES;
	mapTypeSelector.selectedSegmentIndex = appDelegate.mMapTypeSelected;
}

				   
-(IBAction)selectMapMode:(id)sender
{
	mMapStyleIdx = [sender selectedSegmentIndex];
	//NSLog(@"TrafficCamSettingsViewController:selectMapMode %d", nMapStyleIdx);
	//TrafficCameraViewController *MapController = [TrafficCameraViewController alloc];
	//NSLog(@"Before Call");
	//MapController.MapStyleIdx = nMapStyleIdx;
	////NSLog(@"TrafficCameraViewController:MapMode %d", MapController.MapStyleIdx);
	//[TrafficCameraViewController release];

	
}

-(IBAction)sliderChanged:(id)sender
{
	sliderLabel.text = [NSString stringWithFormat:@"%@ Miles",[[NSNumber numberWithInt:slider.value] stringValue]];
}

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}

-(IBAction)CancelButtonPressed:(id)sendr {
	NSLog(@"Cancel Button");
	[vcDelegate onSettingsChildPageDone];
}

-(IBAction)DoneButtonPressed:(id)sendr {
	NSLog(@"Done Button");
	
	
	[vcDelegate SetNewMapType:mMapStyleIdx];
	
	NSLog(@"TrafficCamSettingsViewController:selectMapDistance %@", [[NSNumber numberWithInt:slider.value] stringValue]);
	//TrafficCameraViewController *MapController = [TrafficCameraViewController alloc];
	TrafficCameraAppDelegate *appDelegate = (TrafficCameraAppDelegate *)[[UIApplication sharedApplication] delegate];
	appDelegate.mMapTypeSelected = mMapStyleIdx;
	NSLog(@"Before Call");
	appDelegate.distanceInMiles = [[NSNumber numberWithInt:slider.value] stringValue];
	NSLog(@"TrafficCameraViewController:MapMode %@", appDelegate.distanceInMiles);
	//[TrafficCameraAppDelegate release];

	[vcDelegate onSettingsChildPageDone];
}

- (void)dealloc {
    [super dealloc];
}


@end
