//
//  TrafficCameraViewController.m
//  TrafficCam
//
//  Created by Steve on 10/25/09.
//  Copyright Home 2009. All rights reserved.
//

#import "TrafficCameraViewController.h"
#import "TrafficCam.h"
#import "TrafficCamAnnotation.h"
#import "TrafficCamParser.h"
#import "TrafficCamImageViewController.h"
#import "TrafficCamSettingsViewController.h"
#import	"TrafficCameraAppDelegate.h"

@implementation TrafficCameraViewController

@synthesize mapView = _mapView;
@synthesize ImageController;
@synthesize SettingsController;
@synthesize url;
@synthesize settingsButton;
@synthesize mapDistance;
//@synthesize MapStyleIdx;

/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	[super viewDidLoad];
	//NSLog(@"ViewDidLoad");
	CGRect rctSBLocation = CGRectMake(290,430,settingsButton.frame.size.width,settingsButton.frame.size.width);
	settingsButton.frame = rctSBLocation;
	[self.view addSubview:settingsButton];
	NSLog(@"Setting Map Distance to 100 - View Did Load");
	TrafficCameraAppDelegate *appDelegate = (TrafficCameraAppDelegate *)[[UIApplication sharedApplication] delegate];
	mapDistance = [appDelegate.distanceInMiles intValue];
		
	
	[[UIApplication sharedApplication] setStatusBarStyle: UIStatusBarStyleDefault];
}



/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
	//NSLog(@"TrafficCamViewController:dealloc - ENTRY");
	[self.mapView release];
    [super dealloc];
}

-(void)SetNewMapType:(int)MapStyleIdx{
	//NSLog(@"APRSmapViewController:selectMapMode - New Style=%d",MapStyleIdx);
	switch (MapStyleIdx) {
		case 0:
			self.mapView.mapType = MKMapTypeStandard;
			break;
		case 1:
			self.mapView.mapType = MKMapTypeSatellite;
			break;
		case 2:
			self.mapView.mapType = MKMapTypeHybrid;
			break;
		default:
			//NSLog(@"APRSmapViewController:selectMapMode - Unknown Selection?!");
			break;
	}
	
		
}
#pragma mark -
#pragma mark MKMapViewDelegate



- (MKAnnotationView *)mapView:(MKMapView *)mapView 
            viewForAnnotation:(id <MKAnnotation>)annotation {
	
	//NSLog(@"TrafficCamViewController:viewForAnnotation - ENTRY");
	MKAnnotationView *view = nil;
	////NSLog(@"MKAnnotationView *view = nil;");
	if(annotation != mapView.userLocation) {
		//NSLog(@"TrafficCamViewController: - pin not current location");
		TrafficCamAnnotation *asAnn = (TrafficCamAnnotation*)annotation;
		////NSLog(@"TrafficCamAnnotation *asAnn = (TrafficCamAnnotation*)annotation;");
		view = [self.mapView dequeueReusableAnnotationViewWithIdentifier:@"CamLoc"];
		////NSLog(@"view = [self.mapView dequeueReusableAnnotationViewWithIdentifier:@\"CamLoc\"];");
		if(nil == view) {
			////NSLog(@"inside 2nd if. nil == view if.");
			view = [[[MKPinAnnotationView alloc] initWithAnnotation:asAnn reuseIdentifier:@"CamLoc"] autorelease];
			////NSLog(@"after autorelease");
		}
		
	
		/*
		NSRange rngSearchResult = [asAnn.cam.CamDescription rangeOfString:@"kz0q" options:NSCaseInsensitiveSearch];
		if(rngSearchResult.location != NSNotFound)
		{
			[(MKPinAnnotationView *)view setPinColor:MKPinAnnotationColorGreen];
		}
		*/
		////NSLog(@"pre pin-dropping!");
		[(MKPinAnnotationView *)view setAnimatesDrop:YES];
		[view setCanShowCallout:YES];
		if (asAnn.cam.CamUrl != nil) {
			[view setRightCalloutAccessoryView:[UIButton buttonWithType:UIButtonTypeDetailDisclosure]];
		}
		
		////NSLog(@"Pre-Image-Allocation");
		//[view setLeftCalloutAccessoryView:[[UIImageView alloc]	initWithImage:[UIImage imageWithData: [NSData dataWithContentsOfURL:[NSURL URLWithString:asAnn.cam.CamUrl]]]]];
		////NSLog(@"pin should have dropped now");
		
	} else {
		////NSLog(@"else statement - starts parser");
		if(asParser == nil)
		{
			asParser = [TrafficCamParser newTrafficCamParser];
			////NSLog(@"Parser Started");
			asParser.delegate = self;
		}
		else
		{
			//NSLog(@"TrafficCamViewController:viewForAnnotation  ReUSING Parser?!!");
		}
		[asParser getCamData];
		// THREADED don't do this!  [asParser release];
	}
	////NSLog(@"About to return view!");
	return view;
}

- (void)mapView:(MKMapView *)mapView 
 annotationView:(MKAnnotationView *)view 
calloutAccessoryControlTapped:(UIControl *)control {
	//NSLog(@"CalloutView Button Pressed");
	
	TrafficCamAnnotation *asAnn = (TrafficCamAnnotation *)[view annotation];
	//NSLog(@"Initialized Everything");
	
		self.url = asAnn.cam.CamUrl;
		//NSLog(@"URL set");
	
		//NSLog(@"TrafficCamViewController:onImageActionFlip - Entry URL=%@", asAnn.cam.CamUrl);
		[self onImageActionFlip];
		//NSLog(@"TrafficCamViewController:onImageActionFlip - Exit");
}

-(IBAction)onInfoPress:(id)sender;
{
	//NSLog(@"SettingsViewController:onSettingsActionFlip - ENTRY");
	[self onSettingsActionFlip];
	//NSLog(@"SettingsViewController:onSettingsActionFlip - EXIT");	
}



-(void)onImageChildPageDone
{
	//NSLog(@"SettingsViewController:onChildPageDone - ENTRY");
	[self onImageActionFlip];
	[[UIApplication sharedApplication] setStatusBarStyle: UIStatusBarStyleDefault];

}

-(void)onSettingsChildPageDone
{
	//NSLog(@"SettingsViewController:onChildPageDone - ENTRY");
	[self onSettingsActionFlip];
	[[UIApplication sharedApplication] setStatusBarStyle: UIStatusBarStyleDefault];


	
}


- (void)onImageActionFlip
{
	//NSLog(@"SettingsViewController:onImageActionFlip - ENTRY");
	[UIView setAnimationDelegate:self];
	[UIView setAnimationDidStopSelector:@selector(animationDidStop:animationIDfinished:finished:context:)];
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.75];
	
	if(ImageController == nil)
	{
		ImageController = [[TrafficCamImageViewController alloc] initWithNibName:@"TrafficCamImageViewController" bundle:[NSBundle mainBundle]];
		ImageController.vcDelegate = self;
	}
	//NSLog(@"about to set imageController.ImageURL");
	ImageController.ImageUrl = url; 
	
	[UIView setAnimationTransition:([[ImageController view] superview] ?
									UIViewAnimationTransitionFlipFromLeft : UIViewAnimationTransitionFlipFromRight)
						   forView:self.view cache:YES];
	
	if ([[ImageController view] superview])
	{
		[[ImageController view] removeFromSuperview];
		ImageController = nil;
	}
	else
	{
		[self.view addSubview:[ImageController view]];
	}
	[UIView commitAnimations];
	
	// if we are returning from child page, reset row selection
	//  and then update row display...
}

-(void)onSettingsActionFlip{
	[UIView setAnimationDelegate:self];
	[UIView setAnimationDidStopSelector:@selector(animationDidStop:animationIDfinished:finished:context:)];
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.75];
	
	if(SettingsController == nil)
	{
		SettingsController = [[TrafficCamSettingsViewController alloc] initWithNibName:@"TrafficCamSettingsViewController" bundle:[NSBundle mainBundle]];
		SettingsController.vcDelegate = self;
	}
	
	[UIView setAnimationTransition:([[SettingsController view] superview] ?
									UIViewAnimationTransitionFlipFromLeft : UIViewAnimationTransitionFlipFromRight)
						   forView:self.view cache:YES];
	
	if ([[SettingsController view] superview])
	{
		[[SettingsController view] removeFromSuperview];
		SettingsController = nil;
	}
	else
	{
		[self.view addSubview:[SettingsController view]];
	}
	[UIView commitAnimations];
}



#pragma mark -
#pragma mark Utilty Methods

- (void)recenterMap {
	//NSLog(@"TrafficCamViewController:recenterMap - ENTRY");
	// scan all annotations to determin geographical center...
	NSArray *coordinates = [self.mapView valueForKeyPath:@"annotations.coordinate"];
	CLLocationCoordinate2D maxCoord = {-90.0f, -180.0f};
	CLLocationCoordinate2D minCoord = {90.0f, 180.0f};
	CLLocationCoordinate2D userLocationCoord = self.mapView.userLocation.coordinate;
	for(NSValue *value in coordinates) {
		CLLocationCoordinate2D coord = {0.0f, 0.0f};
		[value getValue:&coord];
		if(userLocationCoord.latitude != coord.latitude ||
		   userLocationCoord.longitude != coord.longitude)
		{
			if(coord.longitude > maxCoord.longitude) {
				maxCoord.longitude = coord.longitude;
			}
			if(coord.latitude > maxCoord.latitude) {
				maxCoord.latitude = coord.latitude;
			}
			if(coord.longitude < minCoord.longitude) {
				minCoord.longitude = coord.longitude;
			}
			if(coord.latitude < minCoord.latitude) {
				minCoord.latitude = coord.latitude;
			}
		}
	}
	// now calculate region of map to display
	MKCoordinateRegion region = {{0.0f, 0.0f}, {0.0f, 0.0f}};
	region.center.longitude = (minCoord.longitude + maxCoord.longitude) / 2.0;
	region.center.latitude = (minCoord.latitude + maxCoord.latitude) / 2.0;
	region.span.longitudeDelta = maxCoord.longitude - minCoord.longitude;
	region.span.latitudeDelta = maxCoord.latitude - minCoord.latitude;
	[self.mapView setRegion:region animated:YES];  
	//NSLog(@"TrafficCamViewController:recenterMap - EXIT");
}

#pragma mark -
#pragma mark TrafficCamParserDelegate

- (void)addTrafficCam:(TrafficCam *)newCam
{
	//NSLog(@"TrafficCamViewController:addTrafficCam (%@) - ENTRY",newCam.CamDescription);
	//if([self.mapView.userLocation.location getDistanceFrom:newCam.CamPosition] < 1500.0f * 5280.0f / 3.0f) {
		TrafficCamAnnotation *newAnn = [TrafficCamAnnotation annotationWithCam:newCam];
		[self.mapView addAnnotation:newAnn];
	//}
}

- (void)parserFinished
{
	//NSLog(@"PARSER ended, recentering map");
	//[asParser release];
	//asParser = nil;
	[self recenterMap];
}


@end
