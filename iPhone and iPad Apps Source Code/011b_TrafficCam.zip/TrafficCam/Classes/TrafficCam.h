//
//  TrafficCam.h
//  APRSkit-MoracoDad
//
//  Created by Steve on 10/25/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import <CoreLocation/CoreLocation.h>


@interface TrafficCam : NSObject {
	NSString   *Description;
	NSString   *Orientation;
	NSString   *URL;
	CLLocation *Position;
	int         InstanceNbr;
}

@property(nonatomic, retain) NSString *CamDescription;
@property(nonatomic, retain) NSString *CamOrientation;
@property(nonatomic, retain) NSString *CamUrl;
@property(nonatomic, retain) CLLocation *CamPosition;
@end
