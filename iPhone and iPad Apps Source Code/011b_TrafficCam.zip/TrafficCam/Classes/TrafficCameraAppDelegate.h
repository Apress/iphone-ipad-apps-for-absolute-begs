//
//  TrafficCamAppDelegate.h
//  TrafficCam
//
//  Created by Steve on 10/25/09.
//  Copyright Home 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TrafficCameraViewController;

@interface TrafficCameraAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    TrafficCameraViewController *viewController;
	NSString *m_strDistanceInMiles;
	int mMapTypeSelected;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet TrafficCameraViewController *viewController;
@property (nonatomic, copy) NSString *distanceInMiles;
@property (nonatomic, assign) int mMapTypeSelected;

@end

