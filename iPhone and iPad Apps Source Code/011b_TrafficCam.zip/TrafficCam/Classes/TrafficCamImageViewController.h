//
//  TrafficCamImageViewController.h
//  TrafficCam
//
//  Created by Steve on 12/6/09.
//  Copyright 2009 Home. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TrafficCameraViewController;

@interface TrafficCamImageViewController : UIViewController {
		NSString *ImageUrl;
		UIImage *imageGottenFromUrl;
		UIImageView *image;
		TrafficCameraViewController *vcDelegate;
}

@property (nonatomic, retain) NSString *ImageUrl;
@property (nonatomic, retain) UIImage *imageGottenFromUrl;
@property (nonatomic, retain) IBOutlet UIImageView *image;
@property (nonatomic, retain) TrafficCameraViewController *vcDelegate;


-(IBAction)BackButtonPressed:(id)sendr;

@end
