//
//  TrafficCam.m
//  APRSkit-MoracoDad
//
//  Created by Steve on 10/25/09.
//  Copyright 2009 Stephen M Moraco. All rights reserved.
//

#import "TrafficCam.h"


@implementation TrafficCam

@synthesize CamDescription = Description;
@synthesize CamOrientation = Orientation;
@synthesize CamUrl = URL;
@synthesize CamPosition = Position;


- (void) dealloc {
	////NSLog(@"TrafficCam:dealloc (%@) - ENTRY",self.CamDescription);
	[self.CamDescription release];
	[self.CamOrientation release];
	[self.CamUrl release];
	[self.CamPosition release];
	[super dealloc];
}

@end
