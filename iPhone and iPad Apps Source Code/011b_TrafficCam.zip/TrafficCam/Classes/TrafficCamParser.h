//
//  TrafficCamParser.h
//  TrafficCam
//
//  Created by Steve on 10/25/09.
//  Copyright 2009 Home. All rights reserved.
//

#import <Foundation/Foundation.h>

@class TrafficCam;
@protocol TrafficCamParserDelegate;

@interface TrafficCamParser : NSObject {
	TrafficCam       *cCurrentCam;
	NSMutableString   *PropertyValue;
	id<TrafficCamParserDelegate> tcpDelegate;
	NSOperationQueue  *RetrieverQueue;
	int lineNbr;
	
	// items for column-based parsing
	NSString          *strElementName;
	int                nElementNbr;
	//int				   subElementNbr;
	NSNumber          *nLatitude;
	NSDate            *TimeOfDataFetch;
}

@property(nonatomic, retain) TrafficCam *currentCam;
@property(nonatomic, retain) NSMutableString *propertyValue;
@property(nonatomic, assign) id<TrafficCamParserDelegate> delegate;
@property(nonatomic, retain) NSOperationQueue *retrieverQueue;

+ (id)newTrafficCamParser;
- (void)getCamData;

@end

@protocol TrafficCamParserDelegate <NSObject>

- (void)addTrafficCam:(TrafficCam *)newCam;
- (void)parserFinished;

@end
