//
//  TrafficCameraViewController.h
//  TrafficCam
//
//  Created by Steve on 10/25/09.
//  Copyright Home 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "TrafficCamParser.h"
#import "TrafficCamImageViewController.h"
#import "TrafficCamSettingsViewController.h"

@interface TrafficCameraViewController : UIViewController <MKMapViewDelegate, TrafficCamParserDelegate> {
	MKMapView *_mapView;
	TrafficCamParser *asParser;
	TrafficCamImageViewController *ImageController;
	TrafficCamSettingsViewController *SettingsController;
	NSString *url;
	UIButton *settingsButton;
	int mapDistance;
	//int MapStyleIdx;
}

@property (nonatomic, retain) IBOutlet MKMapView *mapView;
@property (nonatomic, retain) TrafficCamImageViewController *ImageController;
@property (nonatomic, retain) TrafficCamSettingsViewController *SettingsController;
@property (nonatomic, retain) NSString *url;
@property (nonatomic, retain) IBOutlet UIButton *settingsButton;
@property (nonatomic, assign) int mapDistance;
//@property (nonatomic, assign) int MapStyleIdx;

-(IBAction)onInfoPress:(id)sender;
-(void)onImageActionFlip;
-(void)onSettingsActionFlip;
-(void)onImageChildPageDone;
-(void)onSettingsChildPageDone;
-(void)SetNewMapType:(int)MapStyleIdx;
@end

