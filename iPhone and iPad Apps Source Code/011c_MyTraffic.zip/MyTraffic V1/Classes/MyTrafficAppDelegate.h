//
//  MyTrafficAppDelegate.h
//  MyTraffic
//
//  Created by Satish Rege on 11/30/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

@interface MyTrafficAppDelegate : NSObject <UIApplicationDelegate> {
    
    UIWindow *window;
    UINavigationController *navigationController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;

@end

