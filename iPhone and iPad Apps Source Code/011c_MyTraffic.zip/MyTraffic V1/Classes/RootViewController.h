//
//  RootViewController.h
//  MyTraffic
//
//  Created by Satish Rege on 11/30/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "I25NorthboundController.h"

@interface RootViewController : UITableViewController {
	
	I25NorthboundController *i25NorthboundController;	
	
}
@property (nonatomic, retain) I25NorthboundController *i25NorthboundController;
@end
