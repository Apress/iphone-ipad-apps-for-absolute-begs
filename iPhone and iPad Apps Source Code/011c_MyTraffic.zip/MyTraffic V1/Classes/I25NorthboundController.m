//
//  I25NorthboundController.m
//  MyTraffic
//
//  Created by Satish Rege on 11/30/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//


#import "I25NorthboundController.h"
#import "RootViewController.h"


@implementation I25NorthboundController

@synthesize myWebView;
@synthesize myTextField;
@synthesize myWebViewDelegate;


/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	myWebViewDelegate = [[MyWebViewDelegate alloc] init];
	myWebView.delegate = myWebViewDelegate;
	NSTimer *incrementTimer=  [NSTimer scheduledTimerWithTimeInterval:10.0 target:self selector:@selector(followTimerUpdate:) userInfo:nil repeats:YES];
	[myTextField resignFirstResponder];
	NSURL * url = [NSURL URLWithString:@"http://static.panoramio.com/photos/original/24879621.jpg"];
	
	NSURLRequest * request = [NSURLRequest requestWithURL:url];
	[myWebView loadRequest:request];

    [super viewDidLoad];
}



/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
	myWebView.delegate = nil;
	[myWebViewDelegate release];
	[myTextField release];
	[myWebView release];	
	
    [super dealloc];
}


-(void)followTimerUpdate: (NSTimer*)theTimer  {
	NSURL * url;
	NSURLRequest * request;
	
	
			
		
	[myTextField resignFirstResponder];
	
	//Begin - I25 Camera and Code
	
	if (I25)
	{
		
		//When you are at the last camera in your direction, you return to the first camera in the same direction
				if (northbound) {
			//cameraCoordinate initialized to zero elsewhere and then it circulates from 1 to 27 to 1
			cameraCordinate = cameraCordinate + 1;
			if (cameraCordinate == 28) cameraCordinate =1;
			
		}
		else {
			//cameraCordinate initialized elsewhere to 28 and then it circulates by decrementing from from 27 to 1 to 27
			cameraCordinate = cameraCordinate -1;
			if (cameraCordinate == 0) cameraCordinate = 27;
		}
		
//Choose the camera depending on your co-ordinate

	switch (cameraCordinate) {
		case 1:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=17"];	//Camera - S Academy/ I-25 North
			break;
		case 2:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=18"];	//Camera - HWY 85/87/I-25 N
			break;			
		case 3:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=19"];	//Camera - Stratmoor/ I-25 N
			break;
		case 4:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=50"];	//Camera - Circle/ I-25
			break;			
		case 5:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=16"];	//Camera - MLK Bypass/ I25 S
			break;
		case 6:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=23"];	//Camera - S. Nevada/ I-25 SE
			break;			
		case 7:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=34"];	//Camera - Tejon/ I-25 SE
			break;			
		case 8:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=6"];		//Camera - Mtor City/ I-25 SE
			break;
		case 9:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=51"];	//Camera - Cimmaron/I-25 SE
			break;
		case 10:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=81"];	//Camera - 	Bijou / I25 SW
			break;
		case 11:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=15"];	//Camera - PED Bridge /I-25 S
			break;
		case 12:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=12"];	//Camera - Uintah/I-25 S
			break;
		case 13:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=21"];	//Camera - Fontenero/I25 SW
			break;
		case 14:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=30"];	//Camera - Filmore/ I-25
			break;
		case 15:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=8"];		//Camera - Ellston/ I-25
			break;
		case 16:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=2"];		//Camera - Garden of the Gods/ I-25 SE
			break;
		case 17:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=11"];	// Camera - Rusina/ I-25 SE
			break;
		case 18:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=24"];	//Camera - Woodmen? I-25 S
			break;
		case 19:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=5"];	//Camera - 	PineCreek / I25 S
			break;
		case 20:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=4"];	//Camera - North Academy /I-25 N
			break;
		case 21:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=9"];	//Camera - BriarGate /I-25 S
			break;
		case 22:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=10"];	//Camera - Fontenero/I25 SW
			break;
		case 23:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=29"];	//Camera - Northgate/ I-25
			break;
		case 24:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=31"];	//Camera - Gleneagle/ I-25 S
			break;
		case 25:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=32"];	//Camera - Baptist / I-25 N
			break;
		case 26:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=33"];	// Camera - Monument/ I-25 N
			break;
		case 27:
			url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=49"];	//Camera - CountyLine/ I-25 SE
			break;
		default:
			if (northbound) {
			cameraCordinate = 0;
			}
			else {
				cameraCordinate= 28;
			}
			break;
	}
	}  // End I25 Cameras and Code
	
	//Begin - Academy Code
	
	if (academy)
	{
		//When you are at the last camera in your direction, you return to the first camera in the same direction

		//When you are at the last camera in your direction, you return to the first camera in the same direction
		if (northbound) {
			//cameraCoordinate initialized to zero elsewhere and then it circulates from 1 to 27 to 1
			cameraCordinate = cameraCordinate + 1;
			if (cameraCordinate == 20) cameraCordinate =1;
			
		}
		else {
			//cameraCordinate initialized elsewhere to 28 and then it circulates by decrementing from from 27 to 1 to 27
			cameraCordinate = cameraCordinate -1;
			if (cameraCordinate == 0) cameraCordinate = 19;
		}
	
		
		//Choose the camera depending on your co-ordinate
		
		switch (cameraCordinate) {
			case 1:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=79"];	//Camera - S Academy/ I-25 North
				break;
			case 2:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=80"];	//Camera - HWY 85/87/I-25 N
				break;			
			case 3:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=78"];	//Camera - Stratmoor/ I-25 N
				break;
			case 4:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=77"];	//Camera - Circle/ I-25
				break;			
			case 5:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=76"];	//Camera - MLK Bypass/ I25 S
				break;
			case 6:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=75"];	//Camera - S. Nevada/ I-25 SE
				break;			
			case 7:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=73"];	//Camera - Tejon/ I-25 SE
				break;			
			case 8:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=72"];		//Camera - Mtor City/ I-25 SE
				break;
			case 9:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=74"];	//Camera - Cimmaron/I-25 SE
				break;
			case 10:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=71"];	//Camera - 	Bijou / I25 SW
				break;
			case 11:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=67"];	//Camera - PED Bridge /I-25 S
				break;
			case 12:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=70"];	//Camera - Uintah/I-25 S
				break;
			case 13:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=69"];	//Camera - Fontenero/I25 SW
				break;
			case 14:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=68"];	//Camera - Filmore/ I-25
				break;
			case 15:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=64"];		//Camera - Ellston/ I-25
				break;
			case 16:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=62"];		//Camera - Garden of the Gods/ I-25 SE
				break;
			case 17:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=63"];	// Camera - Rusina/ I-25 SE
				break;
			case 18:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=65"];	//Camera - Woodmen? I-25 S
				break;
			case 19:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=4"];	//Camera - 	PineCreek / I25 S
				break;
			default:
				if (northbound) {
					cameraCordinate = 0;
				}
				else {
					cameraCordinate= 20;
				}
				break;
		}
	}
	
	//End - Academy Code for displaying camera video
	
	//***********************************************************************************************************************************
	//Begin hwy24 code for displaying camera video
	
	if (hwy24)
	{
		//When you are at the last camera in your direction, you return to the first camera in the same direction
		
		//When you are at the last camera in your direction, you return to the first camera in the same direction
		if (westbound) {
			//cameraCoordinate initialized to zero elsewhere and then it circulates from 1 to 12 to 1
			cameraCordinate = cameraCordinate + 1;
			if (cameraCordinate == 13) cameraCordinate =1;
			
		}
		else {
			//cameraCordinate initialized elsewhere to 28 and then it circulates by decrementing from from 12 to 1 to 12
			cameraCordinate = cameraCordinate -1;
			if (cameraCordinate == 0) cameraCordinate = 12;
		}
		
		
		//Choose the camera depending on your co-ordinate
		
		switch (cameraCordinate) {
			case 1:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=79"];	//Camera - S Academy/ I-25 North
				break;
			case 2:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=55"];	//Camera - HWY 85/87/I-25 N
				break;			
			case 3:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=16"];	//Camera - Stratmoor/ I-25 N
				break;
			case 4:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=23"];	//Camera - Circle/ I-25
				break;			
			case 5:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=34"];	//Camera - MLK Bypass/ I25 S
				break;
			case 6:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=6"];	//Camera - S. Nevada/ I-25 SE
				break;			
			case 7:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=51"];	//Camera - Tejon/ I-25 SE
				break;			
			case 8:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=56"];		//Camera - Mtor City/ I-25 SE
				break;
			case 9:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=53"];	//Camera - Cimmaron/I-25 SE
				break;
			case 10:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=54"];	//Camera - 	Bijou / I25 SW
				break;
			case 11:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=58"];	//Camera - PED Bridge /I-25 S
				break;
			case 12:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=57"];	//Camera - Uintah/I-25 S
				break;
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=4"];	//Camera - 	PineCreek / I25 S
				break;
			default:
				if (northbound) {
					cameraCordinate = 0;
				}
				else {
					cameraCordinate= 13;
				}
				break;
		}
	}
	
	
	//End hwy24 cameras
	//************************************************************************************************************************************
	//Begin Nevada cameras
	
	if (nevada)
	{
		//When you are at the last camera in your direction, you return to the first camera in the same direction
		
		//When you are at the last camera in your direction, you return to the first camera in the same direction
		if (northbound) {
			//cameraCoordinate initialized to zero elsewhere and then it circulates from 1 to 12 to 1
			cameraCordinate = cameraCordinate + 1;
			if (cameraCordinate == 8) cameraCordinate =1;
			
		}
		else {
			//cameraCordinate initialized elsewhere to 28 and then it circulates by decrementing from from 12 to 1 to 12
			cameraCordinate = cameraCordinate -1;
			if (cameraCordinate == 0) cameraCordinate = 7;
		}
		
		
		//Choose the camera depending on your co-ordinate
		
		switch (cameraCordinate) {
			case 1:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=23"];	//Camera - S Academy/ I-25 North
				break;
			case 2:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=61"];	//Camera - HWY 85/87/I-25 N
				break;			
			case 3:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=60"];	//Camera - Stratmoor/ I-25 N
				break;
			case 4:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=59"];	//Camera - Circle/ I-25
				break;			
			case 5:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=35"];	//Camera - MLK Bypass/ I25 S
				break;
			case 6:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=27"];	//Camera - S. Nevada/ I-25 SE
				break;			
			case 7:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=7"];	//Camera - Tejon/ I-25 SE
				break;			
			default:
				if (northbound) {
					cameraCordinate = 0;
				}
				else {
					cameraCordinate= 13;
				}
				break;
		}
	}
	
	//End Nevada Cameras
	//***********************************************************************************************************************************************
	//Begin Powers Camera
	
	if (powers)
	{
		//When you are at the last camera in your direction, you return to the first camera in the same direction
		
		//When you are at the last camera in your direction, you return to the first camera in the same direction
		if (northbound) {
			//cameraCoordinate initialized to zero elsewhere and then it circulates from 1 to 12 to 1
			cameraCordinate = cameraCordinate + 1;
			if (cameraCordinate == 2) cameraCordinate =1;
			
		}
		else {
			//cameraCordinate initialized elsewhere to 28 and then it circulates by decrementing from from 12 to 1 to 12
			cameraCordinate = cameraCordinate -1;
			if (cameraCordinate == 0) cameraCordinate = 1;
		}
		
		
		//Choose the camera depending on your co-ordinate
		
		switch (cameraCordinate) {
			case 1:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=26"];	//Camera - S Academy/ I-25 North
				break;
			default:
				if (northbound) {
					cameraCordinate = 0;
				}
				else {
					cameraCordinate= 2;
				}
				break;
		}
	}
	//End Powers Camera
	//***********************************************************************************************************************************************
	//Begin Marksheffel Camera
	if (marksheffel)
	{
		//When you are at the last camera in your direction, you return to the first camera in the same direction
		
		//When you are at the last camera in your direction, you return to the first camera in the same direction
		if (northbound) {
			//cameraCoordinate initialized to zero elsewhere and then it circulates from 1 to 12 to 1
			cameraCordinate = cameraCordinate + 1;
			if (cameraCordinate == 2) cameraCordinate =1;
			
		}
		else {
			//cameraCordinate initialized elsewhere to 28 and then it circulates by decrementing from from 12 to 1 to 12
			cameraCordinate = cameraCordinate -1;
			if (cameraCordinate == 0) cameraCordinate = 1;
		}
		
		
		//Choose the camera depending on your co-ordinate
		
		switch (cameraCordinate) {
			case 1:
				url = [NSURL URLWithString:@"http://www.springsgov.com/trafficeng/bImage.ASP?camID=52"];	//Camera - S Academy/ I-25 North
				break;
			default:
				if (northbound) {
					cameraCordinate = 0;
				}
				else {
					cameraCordinate= 2;
				}
				break;
		}
	}
	//End Marksheffel Camera
//******************************************************************************************************************************************	
	
	
	
	
	request = [NSURLRequest requestWithURL:url];
	[myWebView loadRequest:request];
}


@end