//
//  I25NorthboundController.h
//  MyTraffic
//
//  Created by Satish Rege on 11/30/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyWebViewDelegate.h"

int cameraCordinate;
BOOL northbound, westbound;									//Directional Boolean Variables
BOOL I25, academy, hwy24, nevada, powers, marksheffel;		//Travelling path boolean variables, at anytime only one can be true rest false

@interface I25NorthboundController : UIViewController {
	UITextField * myTextField;
	IBOutlet UIWebView * myWebView;
	MyWebViewDelegate * myWebViewDelegate;

}

@property(nonatomic, retain) UIWebView * myWebView;
@property(nonatomic, retain) UITextField * myTextField;
@property(nonatomic, retain) MyWebViewDelegate * myWebViewDelegate;

@end
