//
//  RootViewController.m
//  MyTraffic
//
//  Created by Satish Rege on 11/30/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "RootViewController.h"


@implementation RootViewController

@synthesize i25NorthboundController;



- (void)viewDidLoad {
    [super viewDidLoad];

    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
 	self.title = @"COS Traffic By the Minute";
}


/*
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}
*/
/*
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}
*/
/*
- (void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
}
*/
/*
- (void)viewDidDisappear:(BOOL)animated {
	[super viewDidDisappear:animated];
}
*/

/*
 // Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Return YES for supported orientations.
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
 */

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release anything that can be recreated in viewDidLoad or on demand.
	// e.g. self.myOutlet = nil;

}


#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 10;
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    
	// Configure the cell.
	
	
	switch (indexPath.row) {
		case 0:
			[cell setText:@"I25 Northbound"];
			break;
		case 1:
			[cell setText:@"I25 Southhbound"];
			break;
		case 2:
			[cell setText:@"Academy Northbound"];
			break;
		case 3:
			[cell setText:@"Academy Southhbound"];
			break;
		case 4:
			[cell setText:@"HWY 24 West"];
			break;
		case 5:
			[cell setText:@"HWY 24 East"];
			break;
		case 6: 
			[cell setText:@"Nevada Northbound"];
			break;
		case 7:
			[cell setText:@"Nevada Southbound"];
			break;
		case 8: 
			[cell setText:@"E Platte & N Powers"];
			break;
		case 9:
			[cell setText:@"E Platte & N Marksheffel"];
			break;
			
			
			

		default:
			[cell setText:@"Error - There should be no row with this index"];
			break;
	}
	
	

   
	
	return cell;
}




// Override to support row selection in the table view.
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	
	//We use the same controller for the northbound and southbound traffic. We begin and display
	//the cameras in the right order.
	 
	I25 = NO;
	academy = NO;
	hwy24 = NO;
	nevada = NO;
	powers = NO;
	marksheffel = NO;
 
	switch (indexPath.row) {
		case 0:
			northbound = YES;
			I25 = YES;
			break;
		case 1:
			northbound = NO;
			I25 = YES;
			break;
		case 2:
			northbound = YES;
			academy= YES;
			break;
		case 3:
			northbound = NO;
			academy = YES;
			break;
		case 4:
			westbound = YES;
			hwy24 = YES;
			break;
		case 5:
			westbound = NO;
			hwy24 = YES;
			break;
		case 6:
			northbound = YES;
			nevada= YES;
			break;
		case 7:
			northbound = NO;
			nevada= YES;
		case 8:
			northbound = YES;
			powers= YES;
			break;
		case 9:
			northbound = YES;
			marksheffel= YES;
		default:
			break;
	}
	
	// Initialize the first camera to be displayed
	if (I25) {	
		if (northbound) cameraCordinate = 0;
		else cameraCordinate = 28;
			}
	
	if (academy) {
		if (northbound) cameraCordinate = 0;
		else cameraCordinate = 20;
			}
	
	if (hwy24) {
		if (westbound) cameraCordinate = 0;
		else cameraCordinate = 13;
	}

	if (nevada) {
		if (northbound) cameraCordinate = 0;
		else cameraCordinate = 8;
	}
	
	if (powers) {
		if (northbound) cameraCordinate = 0;
		else cameraCordinate = 2;
	}
	
	if (marksheffel) {
		if (northbound) cameraCordinate = 0;
		else cameraCordinate = 2;
	}
	
	
	
	

    // Navigation logic may go here -- for example, create and push another view controller.
	
	if (self.i25NorthboundController == nil) {
		I25NorthboundController *i25NorthCamera = [[I25NorthboundController alloc] initWithNibName:@"I25Northbound" 
																							bundle:[NSBundle mainBundle]];
		self.i25NorthboundController = i25NorthCamera;
		[i25NorthCamera release];
	}
	
	[self.navigationController pushViewController:self.i25NorthboundController animated:YES];
	
	
	
	// AnotherViewController *anotherViewController = [[AnotherViewController alloc] initWithNibName:@"AnotherView" bundle:nil];
	// [self.navigationController pushViewController:anotherViewController animated:YES];
	// [anotherViewController release];
}



/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/


/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source.
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }   
}
*/


/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/


/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


- (void)dealloc {
    [super dealloc];
}


@end

