//
//  MyWebViewDelegate.m
//  MyTraffic
//
//  Created by Satish Rege on 12/1/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "MyWebViewDelegate.h"


@implementation MyWebViewDelegate

- (void)webViewDidFinishLoad: (UIWebView *) webView {
	NSLog(@"%@", [webView stringByEvaluatingJavaScriptFromString:
				  @"document.documentElement.textContent"]);
}

@end
