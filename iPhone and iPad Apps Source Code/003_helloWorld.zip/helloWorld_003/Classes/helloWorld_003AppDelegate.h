//
//  helloWorld_003AppDelegate.h
//  helloWorld_003
//
//  Created by Rory Lewis on 8/26/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

@interface helloWorld_003AppDelegate : NSObject <UIApplicationDelegate> {
    
    UIWindow *window;
    UINavigationController *navigationController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;

@end

