//
//  helloWorld_003AppDelegate.m
//  helloWorld_003
//
//  Created by Rory Lewis on 8/26/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "helloWorld_003AppDelegate.h"
#import "RootViewController.h"


@implementation helloWorld_003AppDelegate

@synthesize window;
@synthesize navigationController;


#pragma mark -
#pragma mark Application lifecycle

- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
	
	[window addSubview:[navigationController view]];
    [window makeKeyAndVisible];
}


- (void)applicationWillTerminate:(UIApplication *)application {
	// Save data if appropriate
}


#pragma mark -
#pragma mark Memory management

- (void)dealloc {
	[navigationController release];
	[window release];
	[super dealloc];
}


@end

