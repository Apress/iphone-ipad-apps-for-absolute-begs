    //
//  myPos.m
//  MapKit_01
//
//  Created by Rory Lewis on 2/27/10.
//  Copyright 2010 Apple Inc. All rights reserved.
//
#import "MyPos.h"


@implementation MyPos

@synthesize coordinate, title, subtitle;

-(void)dealloc 
{
	[title release];
	[subtitle release];
	[super dealloc];
}

@end
