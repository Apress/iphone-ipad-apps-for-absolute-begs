//
//  MapKit_01AppDelegate.m
//  MapKit_01
//
//  Created by Rory Lewis on 2/26/10.
//  Copyright Apple Inc 2010. All rights reserved.
//

#import "MapKit_01AppDelegate.h"
#import "MapKit_01ViewController.h"

@implementation MapKit_01AppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
