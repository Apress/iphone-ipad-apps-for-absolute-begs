//
//  MapKit_01ViewController.m
//  MapKit_01
//
//  Created by Rory Lewis on 2/26/10.
//  Copyright Apple Inc 2010. All rights reserved.
//

#import "MapKit_01ViewController.h"
#import "MyPos.h"

@implementation MapKit_01ViewController

@synthesize mapView;


- (void)dealloc 
{
	[mapView release];
    [super dealloc];
}


- (void)viewDidLoad 
{
    [super viewDidLoad];
	
	[mapView setMapType:MKMapTypeStandard];
	[mapView setZoomEnabled:YES];
	[mapView setScrollEnabled:YES];
	mapView.mapType=MKMapTypeHybrid;
	

	
	MKCoordinateRegion region = { {0.0, 0.0 }, { 0.0, 0.0 } };
	region.center.latitude = 38.893432 ;
	region.center.longitude = -104.800161;
	region.span.longitudeDelta = 0.01f;
	region.span.latitudeDelta = 0.01f;	
	[mapView setRegion:region animated:YES];
	[mapView setDelegate:self];
	
	
	
	MyPos *ann = [[MyPos alloc] init];
	ann.title = @"Dr. Rory Lewis";
	ann.subtitle = @"University of Colorado at Colorado Springs";
	ann.coordinate = region.center;
	[mapView addAnnotation:ann];
	
}


- (MKAnnotationView *)mapView:(MKMapView *)mV viewForAnnotation:(id <MKAnnotation>)annotation
{
	MKPinAnnotationView *pinView = nil;
	if(annotation != mapView.userLocation) 
	{
		static NSString *defaultPinID = @"com.rorylewis";
		pinView = (MKPinAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:defaultPinID];
		if ( pinView == nil )
			pinView = [[[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:defaultPinID] autorelease];
		
		pinView.pinColor = MKPinAnnotationColorRed;
		pinView.canShowCallout = YES;
		pinView.animatesDrop = YES;
	}
	else
	{
		[mapView.userLocation setTitle:@"I am here"];
	}
	
    return pinView;
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning 
{
    [super didReceiveMemoryWarning];
}


- (void)viewDidUnload 
{
	
}

@end
