//
//  MapKit_01AppDelegate.h
//  MapKit_01
//
//  Created by Rory Lewis on 2/26/10.
//  Copyright Apple Inc 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MapKit_01ViewController;

@interface MapKit_01AppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    MapKit_01ViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet MapKit_01ViewController *viewController;

@end

