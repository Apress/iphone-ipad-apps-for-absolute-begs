//
//  MapKit_01ViewController.h
//  MapKit_01
//
//  Created by Rory Lewis on 2/26/10.
//  Copyright Apple Inc 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface MapKit_01ViewController : UIViewController <MKMapViewDelegate>{
	IBOutlet MKMapView *mapView;
}

@property (nonatomic, retain) IBOutlet MKMapView *mapView;

@end

