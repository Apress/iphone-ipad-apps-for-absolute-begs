//
//  helloWorld_005AppDelegate.m
//  helloWorld_005
//
//  Created by Rory Lewis on 9/3/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "helloWorld_005AppDelegate.h"
#import "helloWorld_005ViewController.h"

@implementation helloWorld_005AppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
