//
//  helloWorld_005AppDelegate.h
//  helloWorld_005
//
//  Created by Rory Lewis on 9/3/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class helloWorld_005ViewController;

@interface helloWorld_005AppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    helloWorld_005ViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet helloWorld_005ViewController *viewController;

@end

