//
//  helloWorld_005ViewController.h
//  helloWorld_005
//
//  Created by Rory Lewis on 9/3/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface helloWorld_005ViewController : UIViewController {
	IBOutlet UILabel *label;
	IBOutlet UIImageView *uiImageView;
}

@property (nonatomic, retain) IBOutlet UILabel *label;
@property (nonatomic, retain) IBOutlet UIImageView *uiImageView;

- (IBAction)buttonPressed:(id)sender; 
@end

