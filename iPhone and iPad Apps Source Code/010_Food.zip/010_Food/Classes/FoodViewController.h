//
//  FoodViewController.h
//  Food
//
//  Created by Rory Lewis on 2/26/10.
//  Copyright 2010 Apple Inc. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface FoodViewController : UIViewController {
	UIImageView* imageView;
	NSString* imageName;
}

+ (FoodViewController*) foodViewControllerWithImageNamed:(NSString*)name;

@property (nonatomic, assign) IBOutlet UIImageView* imageView;
@property (nonatomic, copy) NSString* imageName;

@end
