//
//  FoodTableViewController.h
//  Food
//
//  Created by Rory Lewis on 2/26/10.
//  Copyright 2010 Apple Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FoodViewController.h"


@interface FoodTableViewController : UITableViewController 
{
	NSArray* names;
}

+ (FoodTableViewController*) foodTableViewControllerWithFoodNames:(NSArray*)foodNames;

@property (nonatomic, retain) NSArray* names;

@end
