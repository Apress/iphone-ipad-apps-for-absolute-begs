//
//  einSwitch003AppDelegate.m
//  einSwitch003
//
//  Created by Rory Lewis on 11/11/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "einSwitch003AppDelegate.h"

@implementation einSwitch003AppDelegate

@synthesize window;
@synthesize tabBarController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    

    [window addSubview:tabBarController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [window release];
	[tabBarController release];
    [super dealloc];
}


@end
