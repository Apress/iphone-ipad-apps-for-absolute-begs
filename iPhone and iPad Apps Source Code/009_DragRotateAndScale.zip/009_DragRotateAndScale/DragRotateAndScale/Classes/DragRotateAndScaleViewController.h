//
//  DragRotateAndScaleViewController.h
//  DragRotateAndScale
//
//  Created by Rory Lewis on 2/23/10.
//  Copyright Apple Inc 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TransformView.h"

@interface DragRotateAndScaleViewController : UIViewController {

}

@end

