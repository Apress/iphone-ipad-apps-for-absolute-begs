//
//  DragRotateAndScaleAppDelegate.h
//  DragRotateAndScale
//
//  Created by Rory Lewis on 2/23/10.
//  Copyright Apple Inc 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DragRotateAndScaleViewController;

@interface DragRotateAndScaleAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    DragRotateAndScaleViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet DragRotateAndScaleViewController *viewController;

@end

