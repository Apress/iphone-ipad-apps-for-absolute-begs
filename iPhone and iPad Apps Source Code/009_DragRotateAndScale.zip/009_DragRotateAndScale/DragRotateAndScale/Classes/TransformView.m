//
//  TransformView.m
//  DragRotateAndScale
//
//  Created by Rory Lewis on 2/23/10.
//  Copyright 2010 Apple Inc. All rights reserved.
//

#import "TransformView.h"


@implementation TransformView

- (id) initWithImage:(UIImage *)image
{
	if (self = [super initWithImage:image])
	{
		[self setUserInteractionEnabled:YES];
		[self setMultipleTouchEnabled:YES];
	}
	
	return self;
}

- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	//Single touch
	if ([touches count] == 1)
	{
		if (!firstTouch)
		{
			firstTouch = [[touches anyObject] retain];
		}
		else if (!secondTouch)
		{
			secondTouch = [[touches anyObject] retain];
		}
	}
	
	//Multiple touch
	if ([touches count] == 2)
	{
		NSArray* theTouches = [touches allObjects];
		[firstTouch release];
		[secondTouch release];
		firstTouch = nil;
		secondTouch = nil;
		firstTouch = [[theTouches objectAtIndex:0] retain];
		secondTouch = [[theTouches objectAtIndex:1] retain];
	}
}

- (void) touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	if ([touches count] == 1)
	{
		CGPoint newTouch = [[touches anyObject] locationInView:[self superview]];
		CGPoint lastTouch = [[touches anyObject] previousLocationInView:[self superview]];
		
		float xDif = newTouch.x - lastTouch.x;
		float yDif = newTouch.y - lastTouch.y;
		
		CGAffineTransform translate = CGAffineTransformMakeTranslation(xDif, yDif);
		[self setTransform: CGAffineTransformConcat([self transform], translate)];
	}
	else if ([touches count] == 2 && firstTouch && secondTouch)
	{
		//Rotate
		float newAngle = [self angleBetweenThisPoint:[firstTouch locationInView:[self superview]]
										andThisPoint:[secondTouch locationInView:[self superview]]];
		float oldAngle = [self angleBetweenThisPoint:[firstTouch previousLocationInView:[self superview]]
										andThisPoint:[secondTouch previousLocationInView:[self superview]]];
		
		CGAffineTransform rotation = CGAffineTransformMakeRotation(oldAngle - newAngle);
		
		[self setTransform: CGAffineTransformConcat([self transform], rotation)];
		
		//Scale
		float newDistance = [self distanceBetweenThisPoint:[firstTouch locationInView:[self superview]]
											  andThisPoint:[secondTouch locationInView:[self superview]]];
		float oldDistance = [self distanceBetweenThisPoint:[firstTouch previousLocationInView:[self superview]]
											  andThisPoint:[secondTouch previousLocationInView:[self superview]]];
		
		float ratio = newDistance / oldDistance;
		
		CGAffineTransform scale = CGAffineTransformMakeScale(ratio, ratio);
		[self setTransform: CGAffineTransformConcat([self transform], scale)];
	}
}

- (void) touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	
}

- (void) touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
	[self touchesEnded:touches withEvent:event];
}

- (float) distanceBetweenThisPoint:(CGPoint)firstPoint  andThisPoint:(CGPoint)secondPoint
{
	float xDif = firstPoint.x - secondPoint.x;
	float yDif = firstPoint.y - secondPoint.y;
	
	float dist = ((xDif * xDif) + (yDif * yDif));
	
	return sqrt(dist);
}

- (float) angleBetweenThisPoint:(CGPoint)firstPoint  andThisPoint:(CGPoint)secondPoint
{
	float xDif = firstPoint.x - secondPoint.x;
	float yDif = firstPoint.y - secondPoint.y;
	
	return atan2(xDif, yDif);
}

- (void)dealloc {
    [super dealloc];
}


@end
