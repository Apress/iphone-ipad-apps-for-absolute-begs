//
//  TransformView.h
//  DragRotateAndScale
//
//  Created by Rory Lewis on 2/23/10.
//  Copyright 2010 Apple Inc. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface TransformView : UIImageView 
{
	UITouch* firstTouch;
	UITouch* secondTouch;
}

- (float) angleBetweenThisPoint:(CGPoint)firstPoint  andThisPoint:(CGPoint)secondPoint;
- (float) distanceBetweenThisPoint:(CGPoint)firstPoint  andThisPoint:(CGPoint)secondPoint;

@end
